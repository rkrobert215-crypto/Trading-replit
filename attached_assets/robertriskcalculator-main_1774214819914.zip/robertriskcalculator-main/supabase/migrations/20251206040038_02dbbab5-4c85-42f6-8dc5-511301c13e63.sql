-- Add user_id column to trades table
ALTER TABLE public.trades 
ADD COLUMN user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE;

-- Drop the overly permissive RLS policy
DROP POLICY IF EXISTS "Allow all operations on trades" ON public.trades;

-- Create secure RLS policies for trades table
CREATE POLICY "Users can view their own trades" 
ON public.trades 
FOR SELECT 
TO authenticated
USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own trades" 
ON public.trades 
FOR INSERT 
TO authenticated
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own trades" 
ON public.trades 
FOR UPDATE 
TO authenticated
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their own trades" 
ON public.trades 
FOR DELETE 
TO authenticated
USING (auth.uid() = user_id);