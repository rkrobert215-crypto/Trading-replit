
-- Drop existing auth-based RLS policies
DROP POLICY IF EXISTS "Users can create their own trades" ON public.trades;
DROP POLICY IF EXISTS "Users can delete their own trades" ON public.trades;
DROP POLICY IF EXISTS "Users can update their own trades" ON public.trades;
DROP POLICY IF EXISTS "Users can view their own trades" ON public.trades;

-- Set default value for user_id so it's not required
ALTER TABLE public.trades ALTER COLUMN user_id SET DEFAULT '00000000-0000-0000-0000-000000000000';

-- Create open policies for personal tool usage
CREATE POLICY "Allow all inserts" ON public.trades FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow all selects" ON public.trades FOR SELECT USING (true);
CREATE POLICY "Allow all updates" ON public.trades FOR UPDATE USING (true) WITH CHECK (true);
CREATE POLICY "Allow all deletes" ON public.trades FOR DELETE USING (true);
