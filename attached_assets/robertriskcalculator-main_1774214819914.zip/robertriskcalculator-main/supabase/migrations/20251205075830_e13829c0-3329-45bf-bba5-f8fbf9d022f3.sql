-- Create trades table with advanced metrics
CREATE TABLE public.trades (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  
  -- Basic trade info
  trade_date DATE NOT NULL DEFAULT CURRENT_DATE,
  symbol TEXT NOT NULL,
  trade_type TEXT NOT NULL CHECK (trade_type IN ('LONG', 'SHORT')),
  instrument TEXT NOT NULL CHECK (instrument IN ('EQUITY', 'OPTIONS')),
  
  -- Entry/Exit
  entry_price DECIMAL(12,2) NOT NULL,
  exit_price DECIMAL(12,2),
  quantity INTEGER NOT NULL,
  
  -- Options specific (nullable for equity)
  option_type TEXT CHECK (option_type IN ('CE', 'PE')),
  strike_price DECIMAL(12,2),
  expiry_date DATE,
  
  -- P&L
  gross_pnl DECIMAL(12,2),
  charges DECIMAL(12,2) DEFAULT 0,
  net_pnl DECIMAL(12,2),
  
  -- Risk metrics
  stop_loss DECIMAL(12,2),
  target DECIMAL(12,2),
  risk_amount DECIMAL(12,2),
  risk_reward_ratio DECIMAL(5,2),
  position_size_percent DECIMAL(5,2),
  capital_at_entry DECIMAL(15,2),
  
  -- Strategy & notes
  strategy TEXT,
  setup_type TEXT,
  notes TEXT,
  
  -- Status
  status TEXT NOT NULL DEFAULT 'OPEN' CHECK (status IN ('OPEN', 'CLOSED', 'PARTIAL')),
  
  -- Sync tracking
  synced_to_sheets BOOLEAN DEFAULT false,
  telegram_notified BOOLEAN DEFAULT false
);

-- Enable Row Level Security
ALTER TABLE public.trades ENABLE ROW LEVEL SECURITY;

-- Create policies for public access (no auth required for now)
CREATE POLICY "Allow all operations on trades" 
ON public.trades 
FOR ALL 
USING (true)
WITH CHECK (true);

-- Create function to update timestamps
CREATE OR REPLACE FUNCTION public.update_trades_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

-- Create trigger for automatic timestamp updates
CREATE TRIGGER update_trades_updated_at
BEFORE UPDATE ON public.trades
FOR EACH ROW
EXECUTE FUNCTION public.update_trades_updated_at();

-- Create index for common queries
CREATE INDEX idx_trades_date ON public.trades(trade_date DESC);
CREATE INDEX idx_trades_status ON public.trades(status);
CREATE INDEX idx_trades_symbol ON public.trades(symbol);