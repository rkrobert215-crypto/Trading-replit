-- Fix nullable user_id issue by adding NOT NULL constraint
-- Table is currently empty, so this is safe to apply

ALTER TABLE public.trades 
ALTER COLUMN user_id SET NOT NULL;