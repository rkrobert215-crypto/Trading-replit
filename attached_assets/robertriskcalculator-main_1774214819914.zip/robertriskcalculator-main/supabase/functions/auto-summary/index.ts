import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { period } = await req.json();

    if (!period || !['daily', 'weekly', 'monthly'].includes(period)) {
      throw new Error('Invalid period. Use daily, weekly, or monthly.');
    }

    const botToken = Deno.env.get('TELEGRAM_BOT_TOKEN');
    const chatId = Deno.env.get('TELEGRAM_CHAT_ID');

    if (!botToken || !chatId) {
      throw new Error('Telegram not configured. Set bot token and chat ID.');
    }

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    // Calculate date range
    const now = new Date();
    let startDate: string;
    const endDate = now.toISOString().split('T')[0];

    if (period === 'daily') {
      startDate = endDate;
    } else if (period === 'weekly') {
      const weekStart = new Date(now);
      const day = weekStart.getDay();
      const diff = day === 0 ? 6 : day - 1;
      weekStart.setDate(now.getDate() - diff);
      startDate = weekStart.toISOString().split('T')[0];
    } else {
      const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
      startDate = monthStart.toISOString().split('T')[0];
    }

    // Query all closed trades in the period (no user filter since auth removed)
    const { data: trades, error } = await supabase
      .from('trades')
      .select('*')
      .gte('trade_date', startDate)
      .lte('trade_date', endDate)
      .eq('status', 'CLOSED');

    if (error) throw error;

    const closedTrades = trades || [];
    const totalTrades = closedTrades.length;
    const winningTrades = closedTrades.filter(t => (t.net_pnl || 0) > 0);
    const losingTrades = closedTrades.filter(t => (t.net_pnl || 0) <= 0);

    const totalNetPnl = closedTrades.reduce((sum: number, t: any) => sum + (t.net_pnl || 0), 0);
    const totalGrossPnl = closedTrades.reduce((sum: number, t: any) => sum + (t.gross_pnl || 0), 0);
    const totalCharges = closedTrades.reduce((sum: number, t: any) => sum + (t.charges || 0), 0);

    const winRate = totalTrades > 0 ? (winningTrades.length / totalTrades) * 100 : 0;

    const avgWin = winningTrades.length > 0
      ? winningTrades.reduce((sum: number, t: any) => sum + (t.net_pnl || 0), 0) / winningTrades.length
      : 0;
    const avgLoss = losingTrades.length > 0
      ? Math.abs(losingTrades.reduce((sum: number, t: any) => sum + (t.net_pnl || 0), 0) / losingTrades.length)
      : 0;

    const largestWin = winningTrades.length > 0
      ? Math.max(...winningTrades.map((t: any) => t.net_pnl || 0))
      : 0;
    const largestLoss = losingTrades.length > 0
      ? Math.min(...losingTrades.map((t: any) => t.net_pnl || 0))
      : 0;

    const totalWinAmount = winningTrades.reduce((sum: number, t: any) => sum + (t.net_pnl || 0), 0);
    const totalLossAmount = Math.abs(losingTrades.reduce((sum: number, t: any) => sum + (t.net_pnl || 0), 0));
    const profitFactor = totalLossAmount > 0 ? totalWinAmount / totalLossAmount : (totalWinAmount > 0 ? Infinity : 0);

    // Build Telegram message
    const periodLabel = period === 'daily' ? '📅 Daily' : period === 'weekly' ? '📅 Weekly' : '📆 Monthly';
    const pnlEmoji = totalNetPnl >= 0 ? '🟢' : '🔴';

    let message = `${periodLabel} *Trading Summary*\n`;
    message += `📊 ${startDate} to ${endDate}\n\n`;

    if (totalTrades === 0) {
      message += `No closed trades in this period.`;
    } else {
      message += `📈 *Performance*\n`;
      message += `• Trades: ${totalTrades} (W: ${winningTrades.length} | L: ${losingTrades.length})\n`;
      message += `• Win Rate: ${winRate.toFixed(1)}%\n\n`;
      message += `💰 *P&L*\n`;
      message += `${pnlEmoji} Net: ₹${totalNetPnl.toFixed(2)}\n`;
      message += `• Gross: ₹${totalGrossPnl.toFixed(2)}\n`;
      message += `• Charges: ₹${totalCharges.toFixed(2)}\n\n`;
      message += `📉 *Stats*\n`;
      message += `• Avg Win: ₹${avgWin.toFixed(2)}\n`;
      message += `• Avg Loss: ₹${avgLoss.toFixed(2)}\n`;
      message += `• Best: ₹${largestWin.toFixed(2)}\n`;
      message += `• Worst: ₹${largestLoss.toFixed(2)}\n`;
      message += `• PF: ${profitFactor === Infinity ? '∞' : profitFactor.toFixed(2)}`;
    }

    // Send to Telegram
    const telegramUrl = `https://api.telegram.org/bot${botToken}/sendMessage`;
    const telegramResponse = await fetch(telegramUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: chatId,
        text: message,
        parse_mode: 'Markdown'
      })
    });

    const telegramResult = await telegramResponse.json();
    console.log(`${period} summary sent to Telegram:`, telegramResult);

    return new Response(
      JSON.stringify({
        success: true,
        period,
        summary: { totalTrades, totalNetPnl: totalNetPnl.toFixed(2), winRate: winRate.toFixed(1) },
        telegram: telegramResult
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error: unknown) {
    console.error('Auto-summary error:', error);
    const message = error instanceof Error ? error.message : 'Unknown error';
    return new Response(
      JSON.stringify({ error: message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
