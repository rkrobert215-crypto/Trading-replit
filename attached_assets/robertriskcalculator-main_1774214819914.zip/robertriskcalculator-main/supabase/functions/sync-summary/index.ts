import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface SummaryData {
  period: 'weekly' | 'monthly';
  startDate: string;
  endDate: string;
  totalTrades: number;
  winningTrades: number;
  losingTrades: number;
  winRate: number;
  totalGrossPnl: number;
  totalCharges: number;
  totalNetPnl: number;
  avgWin: number;
  avgLoss: number;
  largestWin: number;
  largestLoss: number;
  profitFactor: number;
}

async function getAccessToken(serviceAccountJson: string): Promise<string> {
  const serviceAccount = JSON.parse(serviceAccountJson);
  
  const header = { alg: 'RS256', typ: 'JWT' };
  const now = Math.floor(Date.now() / 1000);
  const claim = {
    iss: serviceAccount.client_email,
    scope: 'https://www.googleapis.com/auth/spreadsheets',
    aud: 'https://oauth2.googleapis.com/token',
    exp: now + 3600,
    iat: now,
  };

  const encoder = new TextEncoder();
  const headerB64 = btoa(JSON.stringify(header)).replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
  const claimB64 = btoa(JSON.stringify(claim)).replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
  const signatureInput = `${headerB64}.${claimB64}`;

  const keyData = serviceAccount.private_key
    .replace(/-----BEGIN PRIVATE KEY-----/g, '')
    .replace(/-----END PRIVATE KEY-----/g, '')
    .replace(/\n/g, '');
  
  const binaryKey = Uint8Array.from(atob(keyData), c => c.charCodeAt(0));
  
  const cryptoKey = await crypto.subtle.importKey(
    'pkcs8',
    binaryKey,
    { name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256' },
    false,
    ['sign']
  );

  const signature = await crypto.subtle.sign(
    'RSASSA-PKCS1-v1_5',
    cryptoKey,
    encoder.encode(signatureInput)
  );

  const signatureB64 = btoa(String.fromCharCode(...new Uint8Array(signature)))
    .replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');

  const jwt = `${signatureInput}.${signatureB64}`;

  const tokenResponse = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: `grant_type=urn:ietf:params:oauth:grant-type:jwt-bearer&assertion=${jwt}`,
  });

  const tokenData = await tokenResponse.json();
  return tokenData.access_token;
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const serviceAccountJson = Deno.env.get('GOOGLE_SERVICE_ACCOUNT_JSON');
    if (!serviceAccountJson) {
      throw new Error('Google service account not configured');
    }

    const { spreadsheetId, summary, sendTelegram } = await req.json();
    
    if (!spreadsheetId || !summary) {
      throw new Error('Missing spreadsheetId or summary data');
    }

    const summaryData = summary as SummaryData;
    const sheetName = summaryData.period === 'weekly' ? 'Weekly Summary' : 'Monthly Summary';
    
    console.log(`Syncing ${summaryData.period} summary to sheet: ${sheetName}`);

    const accessToken = await getAccessToken(serviceAccountJson);

    // Check if sheet exists, create if not
    const sheetsUrl = `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}`;
    const sheetInfoResponse = await fetch(sheetsUrl, {
      headers: { 'Authorization': `Bearer ${accessToken}` }
    });
    const sheetInfo = await sheetInfoResponse.json();
    
    const sheetExists = sheetInfo.sheets?.some((s: { properties: { title: string } }) => 
      s.properties.title === sheetName
    );

    if (!sheetExists) {
      console.log(`Creating sheet: ${sheetName}`);
      const addSheetUrl = `${sheetsUrl}:batchUpdate`;
      await fetch(addSheetUrl, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          requests: [{
            addSheet: {
              properties: { title: sheetName }
            }
          }]
        })
      });

      // Add headers
      const headers = [
        'Period Start', 'Period End', 'Total Trades', 'Winning Trades', 'Losing Trades',
        'Win Rate %', 'Gross P&L', 'Charges', 'Net P&L', 'Avg Win', 'Avg Loss',
        'Largest Win', 'Largest Loss', 'Profit Factor', 'Generated At'
      ];

      const headerUrl = `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${encodeURIComponent(sheetName)}!A1:O1?valueInputOption=USER_ENTERED`;
      await fetch(headerUrl, {
        method: 'PUT',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ values: [headers] })
      });
    }

    // Append summary data
    const row = [
      summaryData.startDate,
      summaryData.endDate,
      summaryData.totalTrades,
      summaryData.winningTrades,
      summaryData.losingTrades,
      summaryData.winRate.toFixed(2),
      summaryData.totalGrossPnl.toFixed(2),
      summaryData.totalCharges.toFixed(2),
      summaryData.totalNetPnl.toFixed(2),
      summaryData.avgWin.toFixed(2),
      summaryData.avgLoss.toFixed(2),
      summaryData.largestWin.toFixed(2),
      summaryData.largestLoss.toFixed(2),
      summaryData.profitFactor === Infinity ? 'N/A' : summaryData.profitFactor.toFixed(2),
      new Date().toISOString()
    ];

    const appendUrl = `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${encodeURIComponent(sheetName)}!A:O:append?valueInputOption=USER_ENTERED`;
    const appendResponse = await fetch(appendUrl, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ values: [row] })
    });

    const result = await appendResponse.json();
    console.log('Summary synced to Google Sheets:', result);

    // Send to Telegram if requested
    if (sendTelegram) {
      const botToken = Deno.env.get('TELEGRAM_BOT_TOKEN');
      const chatId = Deno.env.get('TELEGRAM_CHAT_ID');

      if (botToken && chatId) {
        const periodLabel = summaryData.period === 'weekly' ? '📅 Weekly' : '📆 Monthly';
        const pnlEmoji = summaryData.totalNetPnl >= 0 ? '🟢' : '🔴';
        
        let message = `${periodLabel} *Trading Summary*\n\n`;
        message += `📊 Period: ${summaryData.startDate} to ${summaryData.endDate}\n\n`;
        message += `📈 *Performance*\n`;
        message += `• Total Trades: ${summaryData.totalTrades}\n`;
        message += `• Win Rate: ${summaryData.winRate.toFixed(1)}%\n`;
        message += `• Winning: ${summaryData.winningTrades} | Losing: ${summaryData.losingTrades}\n\n`;
        message += `💰 *P&L Summary*\n`;
        message += `${pnlEmoji} Net P&L: ₹${summaryData.totalNetPnl.toFixed(2)}\n`;
        message += `• Gross P&L: ₹${summaryData.totalGrossPnl.toFixed(2)}\n`;
        message += `• Charges: ₹${summaryData.totalCharges.toFixed(2)}\n\n`;
        message += `📉 *Statistics*\n`;
        message += `• Avg Win: ₹${summaryData.avgWin.toFixed(2)}\n`;
        message += `• Avg Loss: ₹${summaryData.avgLoss.toFixed(2)}\n`;
        message += `• Largest Win: ₹${summaryData.largestWin.toFixed(2)}\n`;
        message += `• Largest Loss: ₹${summaryData.largestLoss.toFixed(2)}\n`;
        message += `• Profit Factor: ${summaryData.profitFactor === Infinity ? 'N/A' : summaryData.profitFactor.toFixed(2)}`;

        const telegramUrl = `https://api.telegram.org/bot${botToken}/sendMessage`;
        await fetch(telegramUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            chat_id: chatId,
            text: message,
            parse_mode: 'Markdown'
          })
        });
        console.log('Summary sent to Telegram');
      }
    }

    return new Response(
      JSON.stringify({ success: true }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error: unknown) {
    console.error('Error syncing summary:', error);
    const message = error instanceof Error ? error.message : 'Unknown error';
    return new Response(
      JSON.stringify({ error: message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
