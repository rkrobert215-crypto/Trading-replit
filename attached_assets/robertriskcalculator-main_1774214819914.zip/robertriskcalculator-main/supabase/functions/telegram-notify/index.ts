import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface TradeNotification {
  action: 'NEW' | 'UPDATE' | 'CLOSE';
  symbol: string;
  tradeType: string;
  instrument: string;
  entryPrice: number;
  exitPrice?: number;
  quantity: number;
  netPnl?: number;
  riskRewardRatio?: number;
  status: string;
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const botToken = Deno.env.get('TELEGRAM_BOT_TOKEN');
    const chatId = Deno.env.get('TELEGRAM_CHAT_ID');

    if (!botToken || !chatId) {
      console.error('Missing Telegram credentials');
      return new Response(
        JSON.stringify({ error: 'Telegram not configured' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const trade: TradeNotification = await req.json();
    
    const emoji = trade.action === 'NEW' ? '🆕' : trade.action === 'CLOSE' ? '✅' : '📝';
    const pnlEmoji = (trade.netPnl ?? 0) >= 0 ? '🟢' : '🔴';
    
    let message = `${emoji} *Trade ${trade.action}*\n\n`;
    message += `📊 *${trade.symbol}* (${trade.instrument})\n`;
    message += `📈 Type: ${trade.tradeType}\n`;
    message += `💰 Entry: ₹${trade.entryPrice.toFixed(2)}\n`;
    message += `📦 Qty: ${trade.quantity}\n`;
    
    if (trade.exitPrice) {
      message += `🎯 Exit: ₹${trade.exitPrice.toFixed(2)}\n`;
    }
    
    if (trade.netPnl !== undefined && trade.netPnl !== null) {
      message += `${pnlEmoji} P&L: ₹${trade.netPnl.toFixed(2)}\n`;
    }
    
    if (trade.riskRewardRatio) {
      message += `⚖️ R:R: ${trade.riskRewardRatio.toFixed(2)}\n`;
    }
    
    message += `\n📋 Status: ${trade.status}`;

    const telegramUrl = `https://api.telegram.org/bot${botToken}/sendMessage`;
    
    const response = await fetch(telegramUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: chatId,
        text: message,
        parse_mode: 'Markdown'
      })
    });

    const result = await response.json();
    console.log('Telegram response:', result);

    return new Response(
      JSON.stringify({ success: true, result }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error: unknown) {
    console.error('Error sending Telegram notification:', error);
    const message = error instanceof Error ? error.message : 'Unknown error';
    return new Response(
      JSON.stringify({ error: message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
