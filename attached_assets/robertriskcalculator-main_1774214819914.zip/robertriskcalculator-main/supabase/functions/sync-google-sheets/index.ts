import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface Trade {
  id: string;
  trade_date: string;
  symbol: string;
  trade_type: string;
  instrument: string;
  entry_price: number;
  exit_price: number | null;
  quantity: number;
  option_type: string | null;
  strike_price: number | null;
  gross_pnl: number | null;
  charges: number | null;
  net_pnl: number | null;
  stop_loss: number | null;
  target: number | null;
  risk_reward_ratio: number | null;
  strategy: string | null;
  notes: string | null;
  status: string;
}

async function getAccessToken(serviceAccountJson: string): Promise<string> {
  const serviceAccount = JSON.parse(serviceAccountJson);
  
  const header = {
    alg: 'RS256',
    typ: 'JWT'
  };

  const now = Math.floor(Date.now() / 1000);
  const claim = {
    iss: serviceAccount.client_email,
    scope: 'https://www.googleapis.com/auth/spreadsheets',
    aud: 'https://oauth2.googleapis.com/token',
    exp: now + 3600,
    iat: now
  };

  // Import the private key
  const pemContents = serviceAccount.private_key
    .replace('-----BEGIN PRIVATE KEY-----', '')
    .replace('-----END PRIVATE KEY-----', '')
    .replace(/\n/g, '');
  
  const binaryKey = Uint8Array.from(atob(pemContents), c => c.charCodeAt(0));
  
  const key = await crypto.subtle.importKey(
    'pkcs8',
    binaryKey,
    { name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256' },
    false,
    ['sign']
  );

  // Create JWT
  const encoder = new TextEncoder();
  const headerB64 = btoa(JSON.stringify(header)).replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
  const claimB64 = btoa(JSON.stringify(claim)).replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
  
  const signatureInput = encoder.encode(`${headerB64}.${claimB64}`);
  const signature = await crypto.subtle.sign('RSASSA-PKCS1-v1_5', key, signatureInput);
  const signatureB64 = btoa(String.fromCharCode(...new Uint8Array(signature))).replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
  
  const jwt = `${headerB64}.${claimB64}.${signatureB64}`;

  // Exchange JWT for access token
  const tokenResponse = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: `grant_type=urn:ietf:params:oauth:grant-type:jwt-bearer&assertion=${jwt}`
  });

  const tokenData = await tokenResponse.json();
  return tokenData.access_token;
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const serviceAccountJson = Deno.env.get('GOOGLE_SERVICE_ACCOUNT_JSON');
    if (!serviceAccountJson) {
      return new Response(
        JSON.stringify({ error: 'Google service account not configured' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const { spreadsheetId, trade } = await req.json();
    
    if (!spreadsheetId) {
      return new Response(
        JSON.stringify({ error: 'Spreadsheet ID required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Log details for debugging
    const serviceAccount = JSON.parse(serviceAccountJson);
    console.log('Service Account Email:', serviceAccount.client_email);
    console.log('Spreadsheet ID:', spreadsheetId);

    const accessToken = await getAccessToken(serviceAccountJson);
    
    // Format trade data for sheets
    const row = [
      trade.trade_date,
      trade.symbol,
      trade.trade_type,
      trade.instrument,
      trade.option_type || '',
      trade.strike_price || '',
      trade.entry_price,
      trade.exit_price || '',
      trade.quantity,
      trade.stop_loss || '',
      trade.target || '',
      trade.gross_pnl || '',
      trade.charges || '',
      trade.net_pnl || '',
      trade.risk_reward_ratio || '',
      trade.strategy || '',
      trade.notes || '',
      trade.status,
      new Date().toISOString()
    ];

    const headers = [
      'Date', 'Symbol', 'Type', 'Instrument', 'Option Type', 'Strike',
      'Entry Price', 'Exit Price', 'Quantity', 'Stop Loss', 'Target',
      'Gross P&L', 'Charges', 'Net P&L', 'R:R Ratio', 'Strategy',
      'Notes', 'Status', 'Synced At'
    ];

    // Check if sheet has headers
    const checkUrl = `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/Sheet1!A1:S1`;
    const checkResponse = await fetch(checkUrl, {
      headers: { 'Authorization': `Bearer ${accessToken}` }
    });
    const checkData = await checkResponse.json();
    
    // Add headers if sheet is empty
    if (!checkData.values || checkData.values.length === 0) {
      console.log('Adding headers to sheet...');
      const headerUrl = `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/Sheet1!A1:S1?valueInputOption=USER_ENTERED`;
      await fetch(headerUrl, {
        method: 'PUT',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ values: [headers] })
      });
    }

    // Append trade data
    const appendUrl = `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/Sheet1!A:S:append?valueInputOption=USER_ENTERED`;
    
    const appendResponse = await fetch(appendUrl, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        values: [row]
      })
    });

    const result = await appendResponse.json();
    console.log('Google Sheets response:', result);

    if (!appendResponse.ok) {
      throw new Error(result.error?.message || 'Failed to append to sheet');
    }

    // Update synced status in database
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    await supabase
      .from('trades')
      .update({ synced_to_sheets: true })
      .eq('id', trade.id);

    return new Response(
      JSON.stringify({ success: true, result }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error: unknown) {
    console.error('Error syncing to Google Sheets:', error);
    const message = error instanceof Error ? error.message : 'Unknown error';
    return new Response(
      JSON.stringify({ error: message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
