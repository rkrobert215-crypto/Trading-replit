import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface EquityData {
  date: string;
  symbol?: string;
  tradeDirection: string;
  capital: number;
  deployedCapital: number;
  leverage: number;
  entryPrice: number;
  stopLoss: number;
  targetPrice: number;
  quantity: number;
  positionValue: number;
  riskAmount: number;
  potentialProfit: number;
  riskRewardRatio: number;
  totalCharges: number;
}

interface OptionsData {
  date: string;
  symbol?: string;
  instrumentType: string;
  optionType: string;
  lotSize: number;
  entryPremium: number;
  stopLossPremium: number;
  targetPremium: number;
  capital: number;
  lots: number;
  quantity: number;
  positionValue: number;
  riskAmount: number;
  potentialProfit: number;
  riskRewardRatio: number;
  totalCharges: number;
}

interface FuturesData {
  date: string;
  symbol?: string;
  tradeDirection: string;
  capital: number;
  deployedCapital: number;
  marginPercent: number;
  lotSize: number;
  entryPrice: number;
  stopLoss: number;
  targetPrice: number;
  lots: number;
  quantity: number;
  contractValue: number;
  marginRequired: number;
  riskAmount: number;
  potentialProfit: number;
  riskRewardRatio: number;
  totalCharges: number;
  expiryDate?: string;
}

async function getAccessToken(serviceAccountJson: string): Promise<string> {
  const serviceAccount = JSON.parse(serviceAccountJson);
  
  const header = { alg: 'RS256', typ: 'JWT' };
  const now = Math.floor(Date.now() / 1000);
  const claim = {
    iss: serviceAccount.client_email,
    scope: 'https://www.googleapis.com/auth/spreadsheets',
    aud: 'https://oauth2.googleapis.com/token',
    exp: now + 3600,
    iat: now
  };

  const pemContents = serviceAccount.private_key
    .replace('-----BEGIN PRIVATE KEY-----', '')
    .replace('-----END PRIVATE KEY-----', '')
    .replace(/\n/g, '');
  
  const binaryKey = Uint8Array.from(atob(pemContents), c => c.charCodeAt(0));
  
  const key = await crypto.subtle.importKey(
    'pkcs8',
    binaryKey,
    { name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256' },
    false,
    ['sign']
  );

  const encoder = new TextEncoder();
  const headerB64 = btoa(JSON.stringify(header)).replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
  const claimB64 = btoa(JSON.stringify(claim)).replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
  
  const signatureInput = encoder.encode(`${headerB64}.${claimB64}`);
  const signature = await crypto.subtle.sign('RSASSA-PKCS1-v1_5', key, signatureInput);
  const signatureB64 = btoa(String.fromCharCode(...new Uint8Array(signature))).replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
  
  const jwt = `${headerB64}.${claimB64}.${signatureB64}`;

  const tokenResponse = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: `grant_type=urn:ietf:params:oauth:grant-type:jwt-bearer&assertion=${jwt}`
  });

  const tokenData = await tokenResponse.json();
  return tokenData.access_token;
}

async function ensureSheetExists(accessToken: string, spreadsheetId: string, sheetName: string): Promise<void> {
  // Get spreadsheet info
  const infoUrl = `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}`;
  const infoResponse = await fetch(infoUrl, {
    headers: { 'Authorization': `Bearer ${accessToken}` }
  });
  const spreadsheetInfo = await infoResponse.json();
  
  const sheetExists = spreadsheetInfo.sheets?.some(
    (s: { properties: { title: string } }) => s.properties.title === sheetName
  );
  
  if (!sheetExists) {
    console.log(`Creating sheet: ${sheetName}`);
    const createUrl = `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}:batchUpdate`;
    await fetch(createUrl, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        requests: [{
          addSheet: {
            properties: { title: sheetName }
          }
        }]
      })
    });
  }
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const serviceAccountJson = Deno.env.get('GOOGLE_SERVICE_ACCOUNT_JSON');
    if (!serviceAccountJson) {
      return new Response(
        JSON.stringify({ error: 'Google service account not configured' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const { spreadsheetId, type, data } = await req.json();
    
    if (!spreadsheetId || !type || !data) {
      return new Response(
        JSON.stringify({ error: 'Missing required fields: spreadsheetId, type, data' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log(`Syncing ${type} data to Google Sheets...`);
    const accessToken = await getAccessToken(serviceAccountJson);
    
    let sheetName: string;
    let headers: string[];
    let row: (string | number)[];

    if (type === 'equity') {
      sheetName = 'Equity Calculator';
      headers = [
        'Date', 'Symbol', 'Direction', 'Capital', 'Deployed Capital', 'Leverage',
        'Entry Price', 'Stop Loss', 'Target', 'Quantity', 'Position Value',
        'Risk Amount', 'Potential Profit', 'R:R Ratio', 'Charges'
      ];
      const d = data as EquityData;
      row = [
        d.date,
        d.symbol || '',
        d.tradeDirection,
        d.capital,
        d.deployedCapital,
        d.leverage,
        d.entryPrice,
        d.stopLoss,
        d.targetPrice,
        d.quantity,
        d.positionValue,
        d.riskAmount,
        d.potentialProfit,
        d.riskRewardRatio,
        d.totalCharges
      ];
    } else if (type === 'options') {
      sheetName = 'Options Calculator';
      headers = [
        'Date', 'Symbol', 'Instrument', 'Option Type', 'Lot Size',
        'Entry Premium', 'SL Premium', 'Target Premium', 'Capital',
        'Lots', 'Quantity', 'Position Value', 'Risk Amount',
        'Potential Profit', 'R:R Ratio', 'Charges'
      ];
      const d = data as OptionsData;
      row = [
        d.date,
        d.symbol || '',
        d.instrumentType,
        d.optionType,
        d.lotSize,
        d.entryPremium,
        d.stopLossPremium,
        d.targetPremium,
        d.capital,
        d.lots,
        d.quantity,
        d.positionValue,
        d.riskAmount,
        d.potentialProfit,
        d.riskRewardRatio,
        d.totalCharges
      ];
    } else if (type === 'futures') {
      sheetName = 'Futures Calculator';
      headers = [
        'Date', 'Symbol', 'Direction', 'Capital', 'Deployed Capital', 'Margin %',
        'Lot Size', 'Entry Price', 'Stop Loss', 'Target', 'Expiry',
        'Lots', 'Quantity', 'Contract Value', 'Margin Required',
        'Risk Amount', 'Potential Profit', 'R:R Ratio', 'Charges'
      ];
      const d = data as FuturesData;
      row = [
        d.date,
        d.symbol || '',
        d.tradeDirection,
        d.capital,
        d.deployedCapital,
        d.marginPercent,
        d.lotSize,
        d.entryPrice,
        d.stopLoss,
        d.targetPrice,
        d.expiryDate || '',
        d.lots,
        d.quantity,
        d.contractValue,
        d.marginRequired,
        d.riskAmount,
        d.potentialProfit,
        d.riskRewardRatio,
        d.totalCharges
      ];
    } else {
      return new Response(
        JSON.stringify({ error: 'Invalid type. Must be "equity", "options", or "futures"' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Ensure sheet exists
    await ensureSheetExists(accessToken, spreadsheetId, sheetName);

    // Check if headers exist
    const checkUrl = `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/'${encodeURIComponent(sheetName)}'!A1:P1`;
    const checkResponse = await fetch(checkUrl, {
      headers: { 'Authorization': `Bearer ${accessToken}` }
    });
    const checkData = await checkResponse.json();
    
    // Add headers if needed
    if (!checkData.values || checkData.values.length === 0) {
      console.log(`Adding headers to ${sheetName}...`);
      const headerUrl = `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/'${encodeURIComponent(sheetName)}'!A1:P1?valueInputOption=USER_ENTERED`;
      await fetch(headerUrl, {
        method: 'PUT',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ values: [headers] })
      });
    }

    // Append data
    const appendUrl = `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/'${encodeURIComponent(sheetName)}'!A:P:append?valueInputOption=USER_ENTERED`;
    const appendResponse = await fetch(appendUrl, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ values: [row] })
    });

    const result = await appendResponse.json();
    console.log('Google Sheets response:', result);

    if (!appendResponse.ok) {
      throw new Error(result.error?.message || 'Failed to append to sheet');
    }

    // Send Telegram notification
    const botToken = Deno.env.get('TELEGRAM_BOT_TOKEN');
    const chatId = Deno.env.get('TELEGRAM_CHAT_ID');
    
    if (botToken && chatId) {
      let message = '';
      const timestamp = new Date().toLocaleString('en-IN', { 
        timeZone: 'Asia/Kolkata',
        dateStyle: 'medium',
        timeStyle: 'short'
      });
      
      if (type === 'equity') {
        const d = data as EquityData;
        message = `📊 *Equity Calculator Saved*\n\n`;
        message += `📈 ${d.symbol || 'N/A'} | ${d.tradeDirection}\n`;
        message += `💰 Entry: ₹${d.entryPrice} | SL: ₹${d.stopLoss} | Target: ₹${d.targetPrice}\n`;
        message += `📦 Qty: ${d.quantity} | Position: ₹${d.positionValue.toFixed(0)}\n`;
        message += `⚠️ Risk: ₹${d.riskAmount.toFixed(0)} | Profit: ₹${d.potentialProfit.toFixed(0)}\n`;
        message += `⚖️ R:R: ${d.riskRewardRatio.toFixed(2)}\n`;
        message += `🕐 ${timestamp}`;
      } else if (type === 'options') {
        const d = data as OptionsData;
        message = `📊 *Options Calculator Saved*\n\n`;
        message += `📈 ${d.symbol || 'N/A'} | ${d.instrumentType} ${d.optionType}\n`;
        message += `💰 Entry: ₹${d.entryPremium} | SL: ₹${d.stopLossPremium} | Target: ₹${d.targetPremium}\n`;
        message += `📦 Lots: ${d.lots} (${d.quantity} qty) | Position: ₹${d.positionValue.toFixed(0)}\n`;
        message += `⚠️ Risk: ₹${d.riskAmount.toFixed(0)} | Profit: ₹${d.potentialProfit.toFixed(0)}\n`;
        message += `⚖️ R:R: ${d.riskRewardRatio.toFixed(2)}\n`;
        message += `🕐 ${timestamp}`;
      } else if (type === 'futures') {
        const d = data as FuturesData;
        message = `📊 *Futures Calculator Saved*\n\n`;
        message += `📈 ${d.symbol || 'N/A'} | ${d.tradeDirection}\n`;
        message += `💰 Entry: ₹${d.entryPrice} | SL: ₹${d.stopLoss} | Target: ₹${d.targetPrice}\n`;
        message += `📦 Lots: ${d.lots} (${d.quantity} qty) | Contract: ₹${d.contractValue.toFixed(0)}\n`;
        message += `💵 Margin: ₹${d.marginRequired.toFixed(0)} (${d.marginPercent}%)\n`;
        message += `⚠️ Risk: ₹${d.riskAmount.toFixed(0)} | Profit: ₹${d.potentialProfit.toFixed(0)}\n`;
        message += `⚖️ R:R: ${d.riskRewardRatio.toFixed(2)}\n`;
        message += `🕐 ${timestamp}`;
      }

      try {
        const telegramUrl = `https://api.telegram.org/bot${botToken}/sendMessage`;
        await fetch(telegramUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            chat_id: chatId,
            text: message,
            parse_mode: 'Markdown'
          })
        });
        console.log('Telegram notification sent');
      } catch (telegramError) {
        console.error('Telegram notification failed:', telegramError);
      }
    }

    return new Response(
      JSON.stringify({ success: true, sheet: sheetName }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error: unknown) {
    console.error('Error syncing to Google Sheets:', error);
    const message = error instanceof Error ? error.message : 'Unknown error';
    return new Response(
      JSON.stringify({ error: message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
