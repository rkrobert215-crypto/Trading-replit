import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { getSettings } from "@/components/SettingsPanel";
import { Plus, Download, FileSpreadsheet, TrendingUp, TrendingDown, Edit2, Trash2, X, Check, Calendar, CalendarDays } from "lucide-react";
import type { Trade } from "@/types/trade";

interface FormData {
  trade_date: string;
  symbol: string;
  trade_type: string;
  instrument: string;
  entry_price: number;
  exit_price: number | null;
  quantity: number;
  option_type: string | null;
  strike_price: number | null;
  expiry_date: string | null;
  gross_pnl: number | null;
  charges: number;
  net_pnl: number | null;
  stop_loss: number | null;
  target: number | null;
  risk_amount: number | null;
  risk_reward_ratio: number | null;
  position_size_percent: number | null;
  capital_at_entry: number | null;
  strategy: string;
  setup_type: string;
  notes: string;
  status: string;
}

const defaultTrade: FormData = {
  trade_date: new Date().toISOString().split('T')[0],
  symbol: '',
  trade_type: 'LONG',
  instrument: 'EQUITY',
  entry_price: 0,
  exit_price: null,
  quantity: 1,
  option_type: null,
  strike_price: null,
  expiry_date: null,
  gross_pnl: null,
  charges: 0,
  net_pnl: null,
  stop_loss: null,
  target: null,
  risk_amount: null,
  risk_reward_ratio: null,
  position_size_percent: null,
  capital_at_entry: null,
  strategy: '',
  setup_type: '',
  notes: '',
  status: 'OPEN',
};

export const TradingJournal = () => {
  const [trades, setTrades] = useState<Trade[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formData, setFormData] = useState<FormData>(defaultTrade);
  const [loading, setLoading] = useState(false);
  const [closeTradeDialog, setCloseTradeDialog] = useState<Trade | null>(null);
  const [exitPriceInput, setExitPriceInput] = useState("");
  const { toast } = useToast();
  const { user } = useAuth();

  useEffect(() => {
    if (user) {
      fetchTrades();
    }
  }, [user]);

  const fetchTrades = async () => {
    const { data, error } = await supabase
      .from('trades')
      .select('*')
      .order('trade_date', { ascending: false });
    
    if (error) {
      toast({ title: "Error", description: "Failed to fetch trades", variant: "destructive" });
    } else {
      setTrades((data as Trade[]) || []);
    }
  };

  const calculatePnL = (data: FormData): FormData => {
    if (!data.exit_price || !data.entry_price) return data;
    
    const isLong = data.trade_type === 'LONG';
    const grossPnl = isLong 
      ? (data.exit_price - data.entry_price) * data.quantity
      : (data.entry_price - data.exit_price) * data.quantity;
    
    const charges = data.charges || 0;
    const netPnl = grossPnl - charges;
    
    let riskRewardRatio: number | null = null;
    if (data.stop_loss && data.target) {
      const risk = isLong 
        ? data.entry_price - data.stop_loss 
        : data.stop_loss - data.entry_price;
      const reward = isLong 
        ? data.target - data.entry_price 
        : data.entry_price - data.target;
      riskRewardRatio = risk > 0 ? reward / risk : null;
    }

    let riskAmount: number | null = null;
    if (data.stop_loss) {
      riskAmount = isLong
        ? (data.entry_price - data.stop_loss) * data.quantity
        : (data.stop_loss - data.entry_price) * data.quantity;
    }

    let positionSizePercent: number | null = null;
    if (data.capital_at_entry && data.capital_at_entry > 0) {
      positionSizePercent = ((data.entry_price * data.quantity) / data.capital_at_entry) * 100;
    }

    return {
      ...data,
      gross_pnl: grossPnl,
      net_pnl: netPnl,
      risk_reward_ratio: riskRewardRatio,
      risk_amount: riskAmount,
      position_size_percent: positionSizePercent,
      status: data.exit_price ? 'CLOSED' : 'OPEN'
    };
  };

  const handleSubmit = async () => {
    if (!user) {
      toast({ title: "Login Required", description: "Please sign in to add trades", variant: "destructive" });
      return;
    }

    if (!formData.symbol || !formData.entry_price) {
      toast({ title: "Error", description: "Symbol and Entry Price are required", variant: "destructive" });
      return;
    }

    setLoading(true);
    const calculatedData = calculatePnL(formData);

    try {
      if (editingId) {
        const { error } = await supabase
          .from('trades')
          .update(calculatedData)
          .eq('id', editingId);
        
        if (error) throw error;
        toast({ title: "Success", description: "Trade updated" });
      } else {
        const { data, error } = await supabase
          .from('trades')
          .insert([{ ...calculatedData }])
          .select()
          .single();
        
        if (error) throw error;
        toast({ title: "Success", description: "Trade added" });
        
        // Send Telegram notification
        await sendTelegramNotification({
          action: 'NEW',
          symbol: calculatedData.symbol,
          tradeType: calculatedData.trade_type,
          instrument: calculatedData.instrument,
          entryPrice: calculatedData.entry_price,
          quantity: calculatedData.quantity,
          status: calculatedData.status
        });

        // Sync to Google Sheets if configured
        const settings = getSettings();
        if (settings.spreadsheetId && data) {
          await syncToGoogleSheets(data as Trade);
        }
      }

      setShowForm(false);
      setEditingId(null);
      setFormData(defaultTrade);
      fetchTrades();
    } catch (error: unknown) {
      const message = error instanceof Error ? error.message : 'Unknown error';
      toast({ title: "Error", description: message, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const sendTelegramNotification = async (notification: Record<string, unknown>) => {
    try {
      await supabase.functions.invoke('telegram-notify', {
        body: notification
      });
    } catch (error) {
      console.error('Telegram notification failed:', error);
    }
  };

  const syncToGoogleSheets = async (trade: Trade) => {
    const settings = getSettings();
    if (!settings.spreadsheetId) return;
    
    try {
      await supabase.functions.invoke('sync-google-sheets', {
        body: { spreadsheetId: settings.spreadsheetId, trade }
      });
      toast({ title: "Synced", description: "Trade synced to Google Sheets" });
    } catch (error) {
      console.error('Google Sheets sync failed:', error);
    }
  };

  const handleEdit = (trade: Trade) => {
    setFormData({
      trade_date: trade.trade_date,
      symbol: trade.symbol,
      trade_type: trade.trade_type,
      instrument: trade.instrument,
      entry_price: trade.entry_price,
      exit_price: trade.exit_price,
      quantity: trade.quantity,
      option_type: trade.option_type,
      strike_price: trade.strike_price,
      expiry_date: trade.expiry_date,
      gross_pnl: trade.gross_pnl,
      charges: trade.charges || 0,
      net_pnl: trade.net_pnl,
      stop_loss: trade.stop_loss,
      target: trade.target,
      risk_amount: trade.risk_amount,
      risk_reward_ratio: trade.risk_reward_ratio,
      position_size_percent: trade.position_size_percent,
      capital_at_entry: trade.capital_at_entry,
      strategy: trade.strategy || '',
      setup_type: trade.setup_type || '',
      notes: trade.notes || '',
      status: trade.status,
    });
    setEditingId(trade.id);
    setShowForm(true);
  };

  const handleDelete = async (id: string) => {
    const { error } = await supabase.from('trades').delete().eq('id', id);
    if (error) {
      toast({ title: "Error", description: "Failed to delete trade", variant: "destructive" });
    } else {
      toast({ title: "Deleted", description: "Trade removed" });
      fetchTrades();
    }
  };

  const handleCloseTrade = async () => {
    if (!closeTradeDialog || !exitPriceInput) return;
    const trade = closeTradeDialog;
    const exitPrice = parseFloat(exitPriceInput);
    if (isNaN(exitPrice)) {
      toast({ title: "Error", description: "Please enter a valid exit price", variant: "destructive" });
      return;
    }

    const calculatedData = calculatePnL({
      ...defaultTrade,
      trade_date: trade.trade_date,
      symbol: trade.symbol,
      trade_type: trade.trade_type,
      instrument: trade.instrument,
      entry_price: trade.entry_price,
      quantity: trade.quantity,
      stop_loss: trade.stop_loss,
      target: trade.target,
      capital_at_entry: trade.capital_at_entry,
      exit_price: exitPrice,
      charges: trade.charges || 0,
    });

    const { error } = await supabase
      .from('trades')
      .update({ ...calculatedData, status: 'CLOSED' })
      .eq('id', trade.id);

    if (!error) {
      await sendTelegramNotification({
        action: 'CLOSE',
        symbol: trade.symbol,
        tradeType: trade.trade_type,
        instrument: trade.instrument,
        entryPrice: trade.entry_price,
        exitPrice,
        quantity: trade.quantity,
        netPnl: calculatedData.net_pnl,
        riskRewardRatio: calculatedData.risk_reward_ratio,
        status: 'CLOSED'
      });

      const settings = getSettings();
      if (settings.spreadsheetId) {
        await syncToGoogleSheets({ ...trade, ...calculatedData, exit_price: exitPrice, status: 'CLOSED' });
      }

      fetchTrades();
      toast({ title: "Trade Closed", description: `P&L: ₹${calculatedData.net_pnl?.toFixed(2)}` });
    }

    setCloseTradeDialog(null);
    setExitPriceInput("");
  };

  const exportToCSV = () => {
    const headers = [
      'Date', 'Symbol', 'Type', 'Instrument', 'Option Type', 'Strike', 'Entry', 'Exit', 
      'Qty', 'Stop Loss', 'Target', 'Gross P&L', 'Charges', 'Net P&L', 'R:R', 
      'Risk %', 'Strategy', 'Setup', 'Notes', 'Status'
    ];

    const escapeCSV = (val: unknown) => {
      const str = String(val ?? '');
      if (str.includes(',') || str.includes('"') || str.includes('\n')) {
        return `"${str.replace(/"/g, '""')}"`;
      }
      return str;
    };

    const rows = trades.map(t => [
      t.trade_date, t.symbol, t.trade_type, t.instrument, t.option_type || '',
      t.strike_price || '', t.entry_price, t.exit_price || '', t.quantity,
      t.stop_loss || '', t.target || '', t.gross_pnl || '', t.charges || '',
      t.net_pnl || '', t.risk_reward_ratio || '', t.position_size_percent || '',
      t.strategy || '', t.setup_type || '', t.notes || '', t.status
    ]);

    const csv = [headers, ...rows].map(row => row.map(escapeCSV).join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `trading_journal_${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
  };

  const generateSummary = async (period: 'weekly' | 'monthly') => {
    const now = new Date();
    let startDate: Date;
    
    if (period === 'weekly') {
      startDate = new Date(now);
      startDate.setDate(now.getDate() - 7);
    } else {
      startDate = new Date(now.getFullYear(), now.getMonth(), 1);
    }

    const startStr = startDate.toISOString().split('T')[0];
    const endStr = now.toISOString().split('T')[0];

    const periodTrades = trades.filter(t => {
      const tradeDate = new Date(t.trade_date);
      return tradeDate >= startDate && tradeDate <= now && t.status === 'CLOSED';
    });

    if (periodTrades.length === 0) {
      toast({ title: "No Data", description: `No closed trades found for ${period} period`, variant: "destructive" });
      return;
    }

    const winningTrades = periodTrades.filter(t => (t.net_pnl || 0) > 0);
    const losingTrades = periodTrades.filter(t => (t.net_pnl || 0) < 0);
    
    const totalGrossPnl = periodTrades.reduce((sum, t) => sum + (t.gross_pnl || 0), 0);
    const totalCharges = periodTrades.reduce((sum, t) => sum + (t.charges || 0), 0);
    const totalNetPnl = periodTrades.reduce((sum, t) => sum + (t.net_pnl || 0), 0);
    
    const wins = winningTrades.map(t => t.net_pnl || 0);
    const losses = losingTrades.map(t => Math.abs(t.net_pnl || 0));
    
    const avgWin = wins.length > 0 ? wins.reduce((a, b) => a + b, 0) / wins.length : 0;
    const avgLoss = losses.length > 0 ? losses.reduce((a, b) => a + b, 0) / losses.length : 0;
    const largestWin = wins.length > 0 ? Math.max(...wins) : 0;
    const largestLoss = losses.length > 0 ? Math.max(...losses) : 0;
    
    const totalWins = wins.reduce((a, b) => a + b, 0);
    const totalLosses = losses.reduce((a, b) => a + b, 0);
    const profitFactor = totalLosses > 0 ? totalWins / totalLosses : totalWins > 0 ? Infinity : 0;

    const summary = {
      period,
      startDate: startStr,
      endDate: endStr,
      totalTrades: periodTrades.length,
      winningTrades: winningTrades.length,
      losingTrades: losingTrades.length,
      winRate: periodTrades.length > 0 ? (winningTrades.length / periodTrades.length) * 100 : 0,
      totalGrossPnl,
      totalCharges,
      totalNetPnl,
      avgWin,
      avgLoss,
      largestWin,
      largestLoss,
      profitFactor
    };

    const settings = getSettings();
    setLoading(true);
    try {
      await supabase.functions.invoke('sync-summary', {
        body: { spreadsheetId: settings.spreadsheetId, summary, sendTelegram: true }
      });
      toast({ 
        title: "Summary Generated", 
        description: `${period.charAt(0).toUpperCase() + period.slice(1)} summary sent to Telegram & Google Sheets` 
      });
    } catch (error) {
      console.error('Summary sync failed:', error);
      toast({ title: "Error", description: "Failed to sync summary", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  // Calculate stats
  const totalTrades = trades.length;
  const closedTrades = trades.filter(t => t.status === 'CLOSED');
  const winningTrades = closedTrades.filter(t => (t.net_pnl || 0) > 0);
  const winRate = closedTrades.length > 0 ? (winningTrades.length / closedTrades.length * 100).toFixed(1) : 0;
  const totalPnL = closedTrades.reduce((sum, t) => sum + (t.net_pnl || 0), 0);

  return (
    <div className="space-y-6">
      {/* Close Trade Dialog */}
      <Dialog open={!!closeTradeDialog} onOpenChange={(open) => { if (!open) { setCloseTradeDialog(null); setExitPriceInput(""); } }}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle>Close Trade — {closeTradeDialog?.symbol}</DialogTitle>
            <DialogDescription>
              Entry: ₹{closeTradeDialog?.entry_price} · Qty: {closeTradeDialog?.quantity}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 pt-2">
            <div className="space-y-2">
              <Label htmlFor="exitPrice">Exit Price (₹)</Label>
              <Input
                id="exitPrice"
                type="number"
                step="0.05"
                value={exitPriceInput}
                onChange={(e) => setExitPriceInput(e.target.value)}
                placeholder="Enter exit price"
                autoFocus
                onKeyDown={(e) => { if (e.key === 'Enter') handleCloseTrade(); }}
              />
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => { setCloseTradeDialog(null); setExitPriceInput(""); }}>
                Cancel
              </Button>
              <Button onClick={handleCloseTrade} disabled={!exitPriceInput}>
                Close Trade
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="glass border-border/50">
          <CardContent className="p-4 text-center">
            <p className="text-sm text-muted-foreground">Total Trades</p>
            <p className="text-2xl font-mono font-bold text-primary">{totalTrades}</p>
          </CardContent>
        </Card>
        <Card className="glass border-border/50">
          <CardContent className="p-4 text-center">
            <p className="text-sm text-muted-foreground">Win Rate</p>
            <p className="text-2xl font-mono font-bold text-primary">{winRate}%</p>
          </CardContent>
        </Card>
        <Card className="glass border-border/50">
          <CardContent className="p-4 text-center">
            <p className="text-sm text-muted-foreground">Total P&L</p>
            <p className={`text-2xl font-mono font-bold ${totalPnL >= 0 ? 'text-success' : 'text-destructive'}`}>
              ₹{totalPnL.toFixed(2)}
            </p>
          </CardContent>
        </Card>
        <Card className="glass border-border/50">
          <CardContent className="p-4 text-center">
            <p className="text-sm text-muted-foreground">Open Positions</p>
            <p className="text-2xl font-mono font-bold text-warning">
              {trades.filter(t => t.status === 'OPEN').length}
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Actions */}
      <Card className="glass border-border/50">
        <CardContent className="p-4">
          <div className="flex flex-col sm:flex-row flex-wrap gap-3 items-stretch sm:items-center justify-between">
            <div className="flex flex-wrap gap-2">
              <Button onClick={() => { setShowForm(true); setEditingId(null); setFormData(defaultTrade); }} className="gap-2">
                <Plus size={16} /> Add Trade
              </Button>
              <Button variant="outline" onClick={exportToCSV} className="gap-2">
                <Download size={16} /> <span className="hidden sm:inline">Export</span> CSV
              </Button>
              <Button variant="outline" onClick={() => generateSummary('weekly')} disabled={loading} className="gap-2">
                <Calendar size={16} /> <span className="hidden sm:inline">Weekly</span>
              </Button>
              <Button variant="outline" onClick={() => generateSummary('monthly')} disabled={loading} className="gap-2">
                <CalendarDays size={16} /> <span className="hidden sm:inline">Monthly</span>
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Trade Form */}
      {showForm && (
        <Card className="glass border-primary/30">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle>{editingId ? 'Edit Trade' : 'New Trade'}</CardTitle>
            <Button variant="ghost" size="icon" onClick={() => setShowForm(false)}>
              <X size={20} />
            </Button>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="space-y-2">
                <Label>Date</Label>
                <Input type="date" value={formData.trade_date} onChange={(e) => setFormData({...formData, trade_date: e.target.value})} />
              </div>
              <div className="space-y-2">
                <Label>Symbol</Label>
                <Input placeholder="RELIANCE" value={formData.symbol} onChange={(e) => setFormData({...formData, symbol: e.target.value.toUpperCase()})} />
              </div>
              <div className="space-y-2">
                <Label>Type</Label>
                <Select value={formData.trade_type} onValueChange={(v) => setFormData({...formData, trade_type: v})}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="LONG">LONG</SelectItem>
                    <SelectItem value="SHORT">SHORT</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Instrument</Label>
                <Select value={formData.instrument} onValueChange={(v) => setFormData({...formData, instrument: v})}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="EQUITY">EQUITY</SelectItem>
                    <SelectItem value="OPTIONS">OPTIONS</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {formData.instrument === 'OPTIONS' && (
              <div className="grid grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label>Option Type</Label>
                  <Select value={formData.option_type || ''} onValueChange={(v) => setFormData({...formData, option_type: v})}>
                    <SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="CE">CE</SelectItem>
                      <SelectItem value="PE">PE</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Strike Price</Label>
                  <Input type="number" value={formData.strike_price || ''} onChange={(e) => setFormData({...formData, strike_price: parseFloat(e.target.value) || null})} />
                </div>
                <div className="space-y-2">
                  <Label>Expiry</Label>
                  <Input type="date" value={formData.expiry_date || ''} onChange={(e) => setFormData({...formData, expiry_date: e.target.value})} />
                </div>
              </div>
            )}

            <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
              <div className="space-y-2">
                <Label>Entry Price</Label>
                <Input type="number" step="0.05" value={formData.entry_price || ''} onChange={(e) => setFormData({...formData, entry_price: parseFloat(e.target.value) || 0})} />
              </div>
              <div className="space-y-2">
                <Label>Exit Price</Label>
                <Input type="number" step="0.05" value={formData.exit_price || ''} onChange={(e) => setFormData({...formData, exit_price: parseFloat(e.target.value) || null})} />
              </div>
              <div className="space-y-2">
                <Label>Quantity</Label>
                <Input type="number" value={formData.quantity} onChange={(e) => setFormData({...formData, quantity: parseInt(e.target.value) || 1})} />
              </div>
              <div className="space-y-2">
                <Label>Stop Loss</Label>
                <Input type="number" step="0.05" value={formData.stop_loss || ''} onChange={(e) => setFormData({...formData, stop_loss: parseFloat(e.target.value) || null})} />
              </div>
              <div className="space-y-2">
                <Label>Target</Label>
                <Input type="number" step="0.05" value={formData.target || ''} onChange={(e) => setFormData({...formData, target: parseFloat(e.target.value) || null})} />
              </div>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="space-y-2">
                <Label>Capital at Entry</Label>
                <Input type="number" value={formData.capital_at_entry || ''} onChange={(e) => setFormData({...formData, capital_at_entry: parseFloat(e.target.value) || null})} />
              </div>
              <div className="space-y-2">
                <Label>Charges (₹)</Label>
                <Input type="number" step="0.01" value={formData.charges || 0} onChange={(e) => setFormData({...formData, charges: parseFloat(e.target.value) || 0})} />
              </div>
              <div className="space-y-2">
                <Label>Strategy</Label>
                <Input placeholder="Breakout, Reversal..." value={formData.strategy || ''} onChange={(e) => setFormData({...formData, strategy: e.target.value})} />
              </div>
              <div className="space-y-2">
                <Label>Setup Type</Label>
                <Input placeholder="Gap up, VWAP..." value={formData.setup_type || ''} onChange={(e) => setFormData({...formData, setup_type: e.target.value})} />
              </div>
            </div>

            <div className="space-y-2">
              <Label>Notes</Label>
              <Textarea placeholder="Trade reasoning, lessons learned..." value={formData.notes || ''} onChange={(e) => setFormData({...formData, notes: e.target.value})} />
            </div>

            <Button onClick={handleSubmit} disabled={loading} className="w-full">
              {loading ? 'Saving...' : editingId ? 'Update Trade' : 'Add Trade'}
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Trades List */}
      <div className="space-y-3">
        {trades.map((trade) => (
          <Card key={trade.id} className="glass border-border/50 hover:border-primary/30 transition-colors">
            <CardContent className="p-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-center gap-3 min-w-0">
                  <div className={`w-2 h-12 flex-shrink-0 rounded-full ${trade.status === 'OPEN' ? 'bg-warning' : (trade.net_pnl || 0) >= 0 ? 'bg-success' : 'bg-destructive'}`} />
                  <div className="min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-mono font-bold text-lg">{trade.symbol}</span>
                      <Badge variant={trade.trade_type === 'LONG' ? 'default' : 'destructive'} className="text-xs">
                        {trade.trade_type}
                      </Badge>
                      <Badge variant="outline" className="text-xs">{trade.instrument}</Badge>
                      {trade.option_type && (
                        <Badge variant="secondary" className="text-xs">{trade.strike_price} {trade.option_type}</Badge>
                      )}
                    </div>
                    <div className="flex flex-wrap gap-x-4 gap-y-1 text-sm text-muted-foreground mt-1">
                      <span>{trade.trade_date}</span>
                      <span>Entry: ₹{trade.entry_price}</span>
                      {trade.exit_price && <span>Exit: ₹{trade.exit_price}</span>}
                      <span>Qty: {trade.quantity}</span>
                    </div>
                  </div>
                </div>
                
                <div className="flex items-center gap-3 sm:gap-4 justify-between sm:justify-end">
                  {trade.status === 'CLOSED' && (
                    <div className="text-left sm:text-right">
                      <div className={`font-mono font-bold text-lg ${(trade.net_pnl || 0) >= 0 ? 'text-success' : 'text-destructive'}`}>
                        {(trade.net_pnl || 0) >= 0 ? <TrendingUp className="inline mr-1" size={16} /> : <TrendingDown className="inline mr-1" size={16} />}
                        ₹{trade.net_pnl?.toFixed(2)}
                      </div>
                      {trade.risk_reward_ratio && (
                        <div className="text-xs text-muted-foreground">R:R {trade.risk_reward_ratio.toFixed(2)}</div>
                      )}
                    </div>
                  )}
                  
                  <div className="flex gap-1">
                    {trade.status === 'OPEN' && (
                      <Button variant="ghost" size="icon" onClick={() => { setCloseTradeDialog(trade); setExitPriceInput(""); }} title="Close Trade">
                        <Check size={16} className="text-success" />
                      </Button>
                    )}
                    <Button variant="ghost" size="icon" onClick={() => handleEdit(trade)}>
                      <Edit2 size={16} />
                    </Button>
                    <Button variant="ghost" size="icon" onClick={() => handleDelete(trade.id)}>
                      <Trash2 size={16} className="text-destructive" />
                    </Button>
                  </div>
                </div>
              </div>
              
              {trade.notes && (
                <div className="mt-2 text-sm text-muted-foreground border-t border-border/30 pt-2">
                  {trade.notes}
                </div>
              )}
            </CardContent>
          </Card>
        ))}

        {trades.length === 0 && (
          <Card className="glass border-border/50">
            <CardContent className="p-8 text-center text-muted-foreground">
              No trades yet. Click "Add Trade" to log your first trade.
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
};
