import { useState, useMemo, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { TrendingUp, TrendingDown, Target, Shield, AlertTriangle, IndianRupee, Percent, Save, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { getSettings, AppSettings } from "@/components/SettingsPanel";
import { calculateCharges } from "@/lib/charges";
import { formatCurrency, formatNumber, handleWheel } from "@/lib/formatters";

interface CalculatorInputs {
  symbol: string;
  capital: string;
  deployedCapital: string;
  deployedType: 'percent' | 'fixed';
  leverage: string;
  riskPercent: string;
  riskAmount: string;
  riskType: 'percent' | 'fixed';
  entryPrice: string;
  stopLoss: string;
  targetPrice: string;
  tradeDirection: 'LONG' | 'SHORT';
  useMaxBuyingPower: boolean;
}

const EquityCalculator = () => {
  const { toast } = useToast();
  const [isSaving, setIsSaving] = useState(false);
  const [appSettings, setAppSettings] = useState<AppSettings>(getSettings);
  
  // Listen for settings changes
  useEffect(() => {
    const handleSettingsChange = (e: CustomEvent<AppSettings>) => {
      setAppSettings(e.detail);
    };
    window.addEventListener("settingsChanged", handleSettingsChange as EventListener);
    return () => window.removeEventListener("settingsChanged", handleSettingsChange as EventListener);
  }, []);

  const [inputs, setInputs] = useState<CalculatorInputs>({
    symbol: "",
    capital: "100000",
    deployedCapital: "20",
    deployedType: 'percent',
    leverage: "5",
    riskPercent: "1",
    riskAmount: "1000",
    riskType: 'percent',
    entryPrice: "",
    stopLoss: "",
    targetPrice: "",
    tradeDirection: 'LONG',
    useMaxBuyingPower: false,
  });

  // handleWheel imported from formatters

  const saveToSheets = async () => {
    if (!appSettings.spreadsheetId) {
      toast({ title: "Error", description: "Please set Google Sheet ID in Settings", variant: "destructive" });
      return;
    }
    if (!calculations.isValid) {
      toast({ title: "Error", description: "Please fill in all trade details", variant: "destructive" });
      return;
    }

    setIsSaving(true);
    try {
      const { error } = await supabase.functions.invoke('sync-calculator', {
        body: {
          spreadsheetId: appSettings.spreadsheetId,
          type: 'equity',
          data: {
            date: new Date().toISOString().split('T')[0],
            symbol: inputs.symbol.toUpperCase() || 'N/A',
            tradeDirection: inputs.tradeDirection,
            capital: calculations.totalCapital,
            deployedCapital: calculations.deployedCapital,
            leverage: calculations.leverage,
            entryPrice: parseFloat(inputs.entryPrice),
            stopLoss: parseFloat(inputs.stopLoss),
            targetPrice: parseFloat(inputs.targetPrice),
            quantity: calculations.quantity,
            positionValue: calculations.positionValue,
            riskAmount: calculations.riskAmount,
            potentialProfit: calculations.netProfit,
            riskRewardRatio: calculations.riskRewardRatio,
            totalCharges: calculations.totalCharges,
          }
        }
      });

      if (error) throw error;
      toast({ title: "Success", description: "Saved to Google Sheets!" });
    } catch (error) {
      console.error('Save error:', error);
      toast({ title: "Error", description: "Failed to save to sheets", variant: "destructive" });
    } finally {
      setIsSaving(false);
    }
  };

  const calculations = useMemo(() => {
    const totalCapital = parseFloat(inputs.capital) || 0;
    const deployedPercent = parseFloat(inputs.deployedCapital) || 0;
    const fixedDeployed = parseFloat(inputs.deployedCapital) || 0;
    const leverage = parseFloat(inputs.leverage) || 1;
    const riskPercent = parseFloat(inputs.riskPercent) || 0;
    const fixedRisk = parseFloat(inputs.riskAmount) || 0;
    const entry = parseFloat(inputs.entryPrice) || 0;
    const sl = parseFloat(inputs.stopLoss) || 0;
    const target = parseFloat(inputs.targetPrice) || 0;
    const isLong = inputs.tradeDirection === 'LONG';
    const isCNC = leverage === 1;

    // Calculate deployed capital based on type
    const deployedCapital = inputs.deployedType === 'percent'
      ? (totalCapital * deployedPercent) / 100
      : fixedDeployed;
    
    // Buying power with leverage
    const buyingPower = deployedCapital * leverage;

    // Calculate risk amount based on type (risk is on deployed capital, not total)
    const configuredRiskAmount = inputs.riskType === 'percent' 
      ? (deployedCapital * riskPercent) / 100 
      : fixedRisk;
    const riskPerShare = isLong ? entry - sl : sl - entry;
    
    // Calculate quantity based on mode
    let quantity: number;
    let wasQuantityCapped = false;
    if (inputs.useMaxBuyingPower && entry > 0) {
      // Max buying power mode - use all available buying power
      quantity = Math.floor(buyingPower / entry);
    } else {
      // Risk-based mode
      const riskBasedQty = riskPerShare > 0 ? Math.floor(configuredRiskAmount / riskPerShare) : 0;
      // Cap quantity so margin required doesn't exceed deployed capital
      const maxQtyByCapital = entry > 0 ? Math.floor(buyingPower / entry) : 0;
      if (riskBasedQty > maxQtyByCapital && maxQtyByCapital > 0) {
        quantity = maxQtyByCapital;
        wasQuantityCapped = true;
      } else {
        quantity = riskBasedQty;
      }
    }

    // Required deployed capital to achieve full risk (for capping warning)
    const requiredDeployedCapital = riskPerShare > 0 && entry > 0
      ? Math.ceil((configuredRiskAmount / riskPerShare) * entry / leverage)
      : 0;
    
    // Actual risk amount based on position
    const riskAmount = (inputs.useMaxBuyingPower || wasQuantityCapped)
      ? quantity * riskPerShare 
      : configuredRiskAmount;
    
    const positionValue = quantity * entry;
    
    // Margin required (for leveraged trades, this is position value / leverage)
    const marginRequired = isCNC ? positionValue : positionValue / leverage;
    
    const rewardPerShare = isLong ? target - entry : entry - target;
    const potentialProfit = quantity * rewardPerShare;
    const riskRewardRatio = riskPerShare > 0 ? rewardPerShare / riskPerShare : 0;
    
    // % moves from entry
    const slPercent = entry > 0 ? Math.abs((entry - sl) / entry) * 100 : 0;
    const targetPercent = entry > 0 ? Math.abs((target - entry) / entry) * 100 : 0;
    
    // Capital % at risk (use actual risk amount)
    const capitalAtRiskPercent = totalCapital > 0 ? (riskAmount / totalCapital) * 100 : 0;
    
    // Position exceeds buying power warning
    const exceedsBuyingPower = positionValue > buyingPower;
    
    // Trailing SL levels (1R, 2R, 3R moves)
    const trailingSLLevels = isLong ? {
      costToEntry: entry,
      oneR: entry + riskPerShare,
      twoR: entry + (riskPerShare * 2),
      threeR: entry + (riskPerShare * 3),
    } : {
      costToEntry: entry,
      oneR: entry - riskPerShare,
      twoR: entry - (riskPerShare * 2),
      threeR: entry - (riskPerShare * 3),
    };
    
    // Brokerage estimate - CNC vs Intraday charges
    const segment = isCNC ? 'equity-cnc' as const : 'equity-intraday' as const;
    const charges = calculateCharges(positionValue, segment);
    const totalCharges = charges.total;
    const netProfit = potentialProfit - totalCharges;
    const actualLoss = riskAmount + totalCharges;

    // Validate trade setup
    const isValidSetup = isLong 
      ? (entry > sl && target > entry)
      : (sl > entry && entry > target);

    return {
      riskAmount,
      quantity,
      positionValue,
      marginRequired,
      potentialProfit,
      riskRewardRatio,
      totalCharges,
      netProfit,
      actualLoss,
      isLong,
      isValid: entry > 0 && sl > 0 && target > 0 && quantity > 0 && isValidSetup,
      riskPerShare,
      deployedCapital,
      buyingPower,
      leverage,
      slPercent,
      targetPercent,
      capitalAtRiskPercent,
      exceedsBuyingPower,
      wasQuantityCapped,
      requiredDeployedCapital,
      trailingSLLevels,
      isCNC,
      totalCapital,
    };
  }, [inputs]);

  const handleChange = (field: keyof CalculatorInputs) => (e: React.ChangeEvent<HTMLInputElement>) => {
    setInputs(prev => ({ ...prev, [field]: e.target.value }));
  };

  // formatCurrency and formatNumber imported from @/lib/formatters

  return (
    <div className="grid lg:grid-cols-2 gap-6">
      {/* Input Section */}
      <div className="space-y-6">
        {/* Capital & Risk Card */}
        <div className="glass rounded-xl p-6 space-y-5">
          <div className="flex items-center gap-2 text-primary mb-4">
            <Shield className="w-5 h-5" />
            <h2 className="font-semibold text-lg">Capital & Risk Settings</h2>
          </div>
          
          <div className="space-y-4">
            <div className="space-y-2">
              <Label className="text-muted-foreground flex items-center gap-2">
                <IndianRupee className="w-4 h-4" />
                Total Capital
              </Label>
              <p className="text-[11px] text-muted-foreground/70 -mt-1">Your total trading account balance</p>
              <Input
                type="number"
                value={inputs.capital}
                onChange={handleChange("capital")}
                onWheel={handleWheel}
                placeholder="100000"
              />
            </div>
            
            {/* Deployed Capital */}
            <div className="space-y-2">
              <Label className="text-muted-foreground">Capital Allocation</Label>
              <p className="text-[11px] text-muted-foreground/70 -mt-1">How much of your capital to deploy in this trade</p>
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => setInputs(prev => ({ ...prev, deployedType: 'percent' }))}
                  className={`h-10 rounded-lg font-medium text-sm transition-all flex items-center justify-center gap-1 ${
                    inputs.deployedType === 'percent'
                      ? 'bg-primary text-primary-foreground'
                      : 'bg-secondary text-muted-foreground hover:bg-secondary/80'
                  }`}
                >
                  <Percent className="w-3 h-3" />
                  Percentage
                </button>
                <button
                  onClick={() => setInputs(prev => ({ ...prev, deployedType: 'fixed' }))}
                  className={`h-10 rounded-lg font-medium text-sm transition-all flex items-center justify-center gap-1 ${
                    inputs.deployedType === 'fixed'
                      ? 'bg-primary text-primary-foreground'
                      : 'bg-secondary text-muted-foreground hover:bg-secondary/80'
                  }`}
                >
                  <IndianRupee className="w-3 h-3" />
                  Fixed Amount
                </button>
              </div>
            </div>
            
            {inputs.deployedType === 'percent' ? (
              <div className="space-y-2">
                <Label className="text-muted-foreground flex items-center gap-2">
                  <Percent className="w-4 h-4" />
                  Deploy % of Capital
                </Label>
                <p className="text-[11px] text-muted-foreground/70 -mt-1">e.g., 20% of ₹1L = ₹20,000 deployed</p>
                <Input
                  type="number"
                  value={inputs.deployedCapital}
                  onChange={handleChange("deployedCapital")}
                  onWheel={handleWheel}
                  placeholder="20"
                  step="5"
                />
              </div>
            ) : (
              <div className="space-y-2">
                <Label className="text-muted-foreground flex items-center gap-2">
                  <IndianRupee className="w-4 h-4" />
                  Deploy Amount (₹)
                </Label>
                <p className="text-[11px] text-muted-foreground/70 -mt-1">Fixed rupee amount to use for this trade</p>
                <Input
                  type="number"
                  value={inputs.deployedCapital}
                  onChange={handleChange("deployedCapital")}
                  onWheel={handleWheel}
                  placeholder="20000"
                />
              </div>
            )}
            
            {/* Leverage */}
            <div className="space-y-2">
              <Label className="text-muted-foreground">Leverage</Label>
              <p className="text-[11px] text-muted-foreground/70 -mt-1">CNC = delivery (no leverage), 2x-5x = intraday margin</p>
              <div className="grid grid-cols-5 gap-2">
                {['1', '2', '3', '4', '5'].map((lev) => (
                  <button
                    key={lev}
                    onClick={() => setInputs(prev => ({ ...prev, leverage: lev }))}
                    className={`h-10 rounded-lg font-medium text-sm transition-all ${
                      inputs.leverage === lev
                        ? 'bg-primary text-primary-foreground'
                        : 'bg-secondary text-muted-foreground hover:bg-secondary/80'
                    }`}
                  >
                    {lev === '1' ? 'CNC' : `${lev}x`}
                  </button>
                ))}
              </div>
            </div>
            
            {/* Position Sizing Mode */}
            <div className="space-y-2">
              <Label className="text-muted-foreground">Position Sizing Mode</Label>
              <p className="text-[11px] text-muted-foreground/70 -mt-1">Risk-Based = size by SL risk; Max = use full buying power</p>
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => setInputs(prev => ({ ...prev, useMaxBuyingPower: false }))}
                  className={`h-10 rounded-lg font-medium text-sm transition-all flex items-center justify-center gap-1 ${
                    !inputs.useMaxBuyingPower
                      ? 'bg-primary text-primary-foreground'
                      : 'bg-secondary text-muted-foreground hover:bg-secondary/80'
                  }`}
                >
                  <Shield className="w-3 h-3" />
                  Risk-Based
                </button>
                <button
                  onClick={() => setInputs(prev => ({ ...prev, useMaxBuyingPower: true }))}
                  className={`h-10 rounded-lg font-medium text-sm transition-all flex items-center justify-center gap-1 ${
                    inputs.useMaxBuyingPower
                      ? 'bg-primary text-primary-foreground'
                      : 'bg-secondary text-muted-foreground hover:bg-secondary/80'
                  }`}
                >
                  <TrendingUp className="w-3 h-3" />
                  Max Buying Power
                </button>
              </div>
            </div>
            
            {!inputs.useMaxBuyingPower && (
              <>
                <div className="space-y-2">
                  <Label className="text-muted-foreground">Risk Type</Label>
                  <p className="text-[11px] text-muted-foreground/70 -mt-1">Define risk as % of capital or fixed ₹ amount</p>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => setInputs(prev => ({ ...prev, riskType: 'percent' }))}
                      className={`h-10 rounded-lg font-medium text-sm transition-all flex items-center justify-center gap-1 ${
                        inputs.riskType === 'percent'
                          ? 'bg-primary text-primary-foreground'
                          : 'bg-secondary text-muted-foreground hover:bg-secondary/80'
                      }`}
                    >
                      <Percent className="w-3 h-3" />
                      Percentage
                    </button>
                    <button
                      onClick={() => setInputs(prev => ({ ...prev, riskType: 'fixed' }))}
                      className={`h-10 rounded-lg font-medium text-sm transition-all flex items-center justify-center gap-1 ${
                        inputs.riskType === 'fixed'
                          ? 'bg-primary text-primary-foreground'
                          : 'bg-secondary text-muted-foreground hover:bg-secondary/80'
                      }`}
                    >
                      <IndianRupee className="w-3 h-3" />
                      Fixed Amount
                    </button>
                  </div>
                </div>
                
                {inputs.riskType === 'percent' ? (
                  <div className="space-y-2">
                    <Label className="text-muted-foreground flex items-center gap-2">
                      <Percent className="w-4 h-4" />
                      Risk Per Trade (%)
                    </Label>
                    <p className="text-[11px] text-muted-foreground/70 -mt-1">Max % of capital you can lose (recommended: 1-2%)</p>
                    <Input
                      type="number"
                      value={inputs.riskPercent}
                      onChange={handleChange("riskPercent")}
                      onWheel={handleWheel}
                      placeholder="1"
                      step="0.1"
                    />
                  </div>
                ) : (
                  <div className="space-y-2">
                    <Label className="text-muted-foreground flex items-center gap-2">
                      <IndianRupee className="w-4 h-4" />
                      Risk Amount (₹)
                    </Label>
                    <p className="text-[11px] text-muted-foreground/70 -mt-1">Max rupees you're willing to lose on this trade</p>
                    <Input
                      type="number"
                      value={inputs.riskAmount}
                      onChange={handleChange("riskAmount")}
                      onWheel={handleWheel}
                      placeholder="1000"
                    />
                  </div>
                )}
              </>
            )}
          </div>
        </div>

        {/* Trade Details Card */}
        <div className="glass rounded-xl p-6 space-y-5">
          <div className="flex items-center gap-2 text-primary mb-4">
            <Target className="w-5 h-5" />
            <h2 className="font-semibold text-lg">Trade Setup</h2>
          </div>

          {/* Trade Direction Toggle */}
          <div className="space-y-2">
            <Label className="text-muted-foreground">Trade Direction</Label>
            <p className="text-[11px] text-muted-foreground/70 -mt-1">Long = expect price to rise; Short = expect price to fall</p>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => setInputs(prev => ({ ...prev, tradeDirection: 'LONG' }))}
                className={`h-12 rounded-lg font-semibold transition-all flex items-center justify-center gap-2 ${
                  inputs.tradeDirection === 'LONG'
                    ? 'bg-success text-success-foreground'
                    : 'bg-secondary text-muted-foreground hover:bg-secondary/80'
                }`}
              >
                <TrendingUp className="w-4 h-4" />
                BUY (Long)
              </button>
              <button
                onClick={() => setInputs(prev => ({ ...prev, tradeDirection: 'SHORT' }))}
                className={`h-12 rounded-lg font-semibold transition-all flex items-center justify-center gap-2 ${
                  inputs.tradeDirection === 'SHORT'
                    ? 'bg-destructive text-destructive-foreground'
                    : 'bg-secondary text-muted-foreground hover:bg-secondary/80'
                }`}
              >
                <TrendingDown className="w-4 h-4" />
                SELL (Short)
              </button>
            </div>
          </div>
          
          <div className="space-y-4">
            <div className="space-y-2">
              <Label className="text-muted-foreground">Stock Symbol</Label>
              <p className="text-[11px] text-muted-foreground/70 -mt-1">NSE ticker name of the stock you want to trade</p>
              <Input
                type="text"
                value={inputs.symbol}
                onChange={handleChange("symbol")}
                placeholder="e.g., RELIANCE, TCS, INFY"
                className="uppercase"
              />
            </div>

            <div className="space-y-2">
              <Label className="text-muted-foreground">Entry Price (₹)</Label>
              <p className="text-[11px] text-muted-foreground/70 -mt-1">Price at which you plan to enter the trade</p>
              <Input
                type="number"
                value={inputs.entryPrice}
                onChange={handleChange("entryPrice")}
                onWheel={handleWheel}
                placeholder="Enter entry price"
                step="0.05"
              />
            </div>
            
            <div className="space-y-2">
              <Label className="text-muted-foreground flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-destructive" />
                Stop Loss (₹) {inputs.tradeDirection === 'LONG' ? '(Below Entry)' : '(Above Entry)'}
              </Label>
              <p className="text-[11px] text-muted-foreground/70 -mt-1">Exit price to limit your loss if trade goes wrong</p>
              <Input
                type="number"
                value={inputs.stopLoss}
                onChange={handleChange("stopLoss")}
                onWheel={handleWheel}
                placeholder="Enter stop loss"
                step="0.05"
              />
            </div>
            
            <div className="space-y-2">
              <Label className="text-muted-foreground flex items-center gap-2">
                <Target className="w-4 h-4 text-success" />
                Target Price (₹) {inputs.tradeDirection === 'LONG' ? '(Above Entry)' : '(Below Entry)'}
              </Label>
              <p className="text-[11px] text-muted-foreground/70 -mt-1">Exit price to book profit when trade goes your way</p>
              <Input
                type="number"
                value={inputs.targetPrice}
                onChange={handleChange("targetPrice")}
                onWheel={handleWheel}
                placeholder="Enter target price"
                step="0.05"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Save to Google Sheets */}
      <div className="glass rounded-xl p-4 sm:p-6 mt-6 sticky top-0 z-30 md:static md:z-auto">
        <div className="flex items-center gap-2 text-primary mb-4">
          <Save className="w-5 h-5" />
          <h2 className="font-semibold text-lg">Save & Send Alert</h2>
        </div>
        <div className="flex flex-col sm:flex-row gap-3 items-center">
          <div className="flex-1 text-sm text-muted-foreground">
            {appSettings.spreadsheetId ? (
              <span className="text-success">✓ Sheet ID configured in Settings</span>
            ) : (
              <span className="text-warning">⚠ Configure Sheet ID in Settings (⚙️ icon)</span>
            )}
          </div>
          <Button 
            onClick={saveToSheets} 
            disabled={isSaving || !calculations.isValid || !appSettings.spreadsheetId}
            className="gap-2 bg-primary hover:bg-primary/90"
          >
            {isSaving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
            {isSaving ? 'Saving...' : 'Save & Send'}
          </Button>
        </div>
        <p className="text-xs text-muted-foreground mt-2">
          Saves to "Equity Calculator" sheet and sends Telegram alert.
        </p>
      </div>

      {/* Results Section */}
      <div className="space-y-6">
        {/* Position Size Card */}
        <div className="glass rounded-xl p-6 animate-scale-in">
          <div className="flex items-center justify-between mb-6">
            <h2 className="font-semibold text-lg text-foreground">Position Size</h2>
            {calculations.isValid && (
              <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                calculations.isLong 
                  ? 'bg-success/20 text-success' 
                  : 'bg-destructive/20 text-destructive'
              }`}>
                {calculations.isLong ? '↑ LONG' : '↓ SHORT'}
              </span>
            )}
          </div>
          
          {calculations.wasQuantityCapped && (
            <div className="flex items-start gap-2 p-3 rounded-lg bg-warning/10 border border-warning/30 mb-4">
              <AlertTriangle className="w-4 h-4 text-warning shrink-0 mt-0.5" />
              <div className="flex-1">
                <p className="text-sm text-warning">
                  Quantity capped to fit buying power ({formatCurrency(calculations.buyingPower)}). Need {formatCurrency(calculations.requiredDeployedCapital)} deployed capital for full risk.
                </p>
                <Button
                  variant="outline"
                  size="sm"
                  className="mt-2 h-7 text-xs border-warning/50 text-warning hover:bg-warning/10"
                  onClick={() => {
                    const required = calculations.requiredDeployedCapital;
                    if (inputs.deployedType === 'percent') {
                      const percent = calculations.totalCapital > 0 ? ((required / calculations.totalCapital) * 100).toFixed(1) : '0';
                      setInputs(prev => ({ ...prev, deployedCapital: percent }));
                    } else {
                      setInputs(prev => ({ ...prev, deployedCapital: String(required) }));
                    }
                    toast({ title: "Capital Adjusted", description: `Deployed capital set to ${formatCurrency(required)}` });
                  }}
                >
                  Auto-adjust to {formatCurrency(calculations.requiredDeployedCapital)}
                </Button>
              </div>
            </div>
          )}

          <div className="grid grid-cols-2 gap-4">
            <div className="bg-secondary/50 rounded-lg p-4">
              <p className="text-muted-foreground text-sm mb-1">Quantity</p>
              <p className="text-3xl font-bold text-foreground number-ticker">
                {calculations.quantity}
              </p>
              <p className="text-muted-foreground text-xs">shares</p>
            </div>
            
            <div className="bg-secondary/50 rounded-lg p-4">
              <p className="text-muted-foreground text-sm mb-1">Position Value</p>
              <p className="text-2xl font-bold text-foreground number-ticker">
                {formatCurrency(calculations.positionValue)}
              </p>
              <p className="text-muted-foreground text-xs">total exposure</p>
            </div>
            
            <div className="bg-secondary/50 rounded-lg p-4">
              <p className="text-muted-foreground text-sm mb-1">Margin Required</p>
              <p className="text-xl font-bold text-foreground number-ticker">
                {formatCurrency(calculations.marginRequired)}
              </p>
              <p className="text-muted-foreground text-xs">from deployed capital</p>
            </div>
            
            <div className="bg-primary/10 border border-primary/30 rounded-lg p-4">
              <p className="text-muted-foreground text-sm mb-1">Buying Power ({calculations.leverage}x)</p>
              <p className="text-xl font-bold text-primary number-ticker">
                {formatCurrency(calculations.buyingPower)}
              </p>
              <p className="text-muted-foreground text-xs">max position capacity</p>
            </div>
          </div>
        </div>

        {/* Risk Reward Card */}
        <div className="glass rounded-xl p-6 animate-scale-in" style={{ animationDelay: '0.1s' }}>
          <h2 className="font-semibold text-lg text-foreground mb-6">Risk & Reward</h2>
          
          <div className="space-y-4">
            {/* Risk Reward Ratio Visual */}
            <div className="relative h-10 rounded-lg overflow-hidden bg-secondary">
              <div 
                className="absolute inset-y-0 left-0 bg-destructive/80 flex items-center justify-center"
                style={{ width: calculations.riskRewardRatio > 0 ? `${100 / (1 + calculations.riskRewardRatio)}%` : '50%' }}
              >
                <span className="text-xs font-medium text-destructive-foreground">RISK</span>
              </div>
              <div 
                className="absolute inset-y-0 right-0 bg-success/80 flex items-center justify-center"
                style={{ width: calculations.riskRewardRatio > 0 ? `${(100 * calculations.riskRewardRatio) / (1 + calculations.riskRewardRatio)}%` : '50%' }}
              >
                <span className="text-xs font-medium text-success-foreground">REWARD</span>
              </div>
            </div>
            
            <div className="flex items-center justify-center gap-2 py-2">
              <span className="text-muted-foreground">Risk : Reward</span>
              <span className={`text-2xl font-bold number-ticker ${
                calculations.riskRewardRatio >= 2 ? 'text-success' : 
                calculations.riskRewardRatio >= 1 ? 'text-warning' : 'text-destructive'
              }`}>
                1 : {formatNumber(calculations.riskRewardRatio)}
              </span>
            </div>
            
            <div className="grid grid-cols-2 gap-4 pt-2">
              <div className="bg-destructive/10 border border-destructive/30 rounded-lg p-4">
                <div className="flex items-center gap-2 mb-2">
                  <AlertTriangle className="w-4 h-4 text-destructive" />
                  <p className="text-muted-foreground text-sm">Max Loss</p>
                </div>
                <p className="text-xl font-bold text-destructive number-ticker">
                  {formatCurrency(calculations.actualLoss)}
                </p>
                <p className="text-muted-foreground text-xs">including charges</p>
              </div>
              
              <div className="bg-success/10 border border-success/30 rounded-lg p-4">
                <div className="flex items-center gap-2 mb-2">
                  <TrendingUp className="w-4 h-4 text-success" />
                  <p className="text-muted-foreground text-sm">Net Profit</p>
                </div>
                <p className="text-xl font-bold text-success number-ticker">
                  {formatCurrency(calculations.netProfit)}
                </p>
                <p className="text-muted-foreground text-xs">after charges</p>
              </div>
            </div>
          </div>
        </div>

        {/* Position Limit Warning */}
        {calculations.exceedsBuyingPower && calculations.positionValue > 0 && (
          <div className="glass rounded-xl p-4 border-2 border-warning animate-scale-in bg-warning/10" style={{ animationDelay: '0.15s' }}>
            <div className="flex items-center gap-3">
              <AlertTriangle className="w-6 h-6 text-warning flex-shrink-0" />
              <div>
                <p className="font-semibold text-warning">Position Exceeds Buying Power</p>
                <p className="text-sm text-muted-foreground">
                  Position value ({formatCurrency(calculations.positionValue)}) exceeds your buying power ({formatCurrency(calculations.buyingPower)})
                </p>
              </div>
            </div>
          </div>
        )}

        {/* % Moves & Capital at Risk */}
        <div className="glass rounded-xl p-6 animate-scale-in" style={{ animationDelay: '0.2s' }}>
          <h2 className="font-semibold text-lg text-foreground mb-4">Trade Metrics</h2>
          
          <div className="grid grid-cols-3 gap-3">
            <div className="bg-destructive/10 border border-destructive/30 rounded-lg p-3 text-center">
              <p className="text-muted-foreground text-xs mb-1">SL Move</p>
              <p className="text-lg font-bold text-destructive number-ticker">
                -{formatNumber(calculations.slPercent, 1)}%
              </p>
            </div>
            <div className="bg-success/10 border border-success/30 rounded-lg p-3 text-center">
              <p className="text-muted-foreground text-xs mb-1">Target Move</p>
              <p className="text-lg font-bold text-success number-ticker">
                +{formatNumber(calculations.targetPercent, 1)}%
              </p>
            </div>
            <div className="bg-primary/10 border border-primary/30 rounded-lg p-3 text-center">
              <p className="text-muted-foreground text-xs mb-1">Capital at Risk</p>
              <p className={`text-lg font-bold number-ticker ${
                calculations.capitalAtRiskPercent > 5 ? 'text-destructive' : 
                calculations.capitalAtRiskPercent > 2 ? 'text-warning' : 'text-primary'
              }`}>
                {formatNumber(calculations.capitalAtRiskPercent, 2)}%
              </p>
            </div>
          </div>
        </div>

        {/* Trailing SL Levels */}
        <div className="glass rounded-xl p-6 animate-scale-in" style={{ animationDelay: '0.25s' }}>
          <h2 className="font-semibold text-lg text-foreground mb-4">Trailing SL Levels</h2>
          <p className="text-xs text-muted-foreground mb-4">Move SL to these levels as price reaches each target</p>
          
          <div className="space-y-3">
            <div className="flex items-center justify-between p-3 rounded-lg bg-secondary/50">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-muted-foreground"></div>
                <span className="text-sm text-muted-foreground">At 1R profit</span>
              </div>
              <div className="text-right">
                <p className="font-mono font-semibold text-foreground">₹{formatNumber(calculations.trailingSLLevels.costToEntry, 2)}</p>
                <p className="text-xs text-muted-foreground">Move SL to Entry (Cost)</p>
              </div>
            </div>
            <div className="flex items-center justify-between p-3 rounded-lg bg-secondary/50">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-success"></div>
                <span className="text-sm text-muted-foreground">At 2R profit</span>
              </div>
              <div className="text-right">
                <p className="font-mono font-semibold text-success">₹{formatNumber(calculations.trailingSLLevels.oneR, 2)}</p>
                <p className="text-xs text-muted-foreground">Trail to 1R ({calculations.isLong ? '+' : '-'}₹{formatNumber(calculations.riskPerShare, 2)})</p>
              </div>
            </div>
            <div className="flex items-center justify-between p-3 rounded-lg bg-secondary/50">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-success"></div>
                <span className="text-sm text-muted-foreground">At 3R profit</span>
              </div>
              <div className="text-right">
                <p className="font-mono font-semibold text-success">₹{formatNumber(calculations.trailingSLLevels.twoR, 2)}</p>
                <p className="text-xs text-muted-foreground">Trail to 2R ({calculations.isLong ? '+' : '-'}₹{formatNumber(calculations.riskPerShare * 2, 2)})</p>
              </div>
            </div>
          </div>
        </div>

        {/* Charges Breakdown */}
        <div className="glass rounded-xl p-6 animate-scale-in" style={{ animationDelay: '0.3s' }}>
          <h2 className="font-semibold text-lg text-foreground mb-4">
            Estimated Charges 
            <span className="text-xs font-normal text-muted-foreground ml-2">
              ({calculations.isCNC ? 'CNC/Delivery' : 'Intraday'})
            </span>
          </h2>
          
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Brokerage</span>
              <span className="text-foreground number-ticker">₹{formatNumber(calculations.totalCharges * 0.3, 0)}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">STT + Exchange + SEBI</span>
              <span className="text-foreground number-ticker">₹{formatNumber(calculations.totalCharges * 0.5, 0)}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">GST + Stamp Duty</span>
              <span className="text-foreground number-ticker">₹{formatNumber(calculations.totalCharges * 0.2, 0)}</span>
            </div>
            <div className="border-t border-border pt-2 mt-2 flex justify-between font-medium">
              <span className="text-foreground">Total Charges</span>
              <span className="text-primary number-ticker">₹{formatNumber(calculations.totalCharges, 0)}</span>
            </div>
          </div>
        </div>
      </div>

    </div>
  );
};

export default EquityCalculator;
