import { useState, useMemo, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { TrendingUp, TrendingDown, Target, Shield, AlertTriangle, IndianRupee, Percent, Save, Loader2, Calendar } from "lucide-react";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { getSettings, AppSettings } from "@/components/SettingsPanel";
import { calculateCharges } from "@/lib/charges";
import { formatCurrency, formatNumber, handleWheel } from "@/lib/formatters";

interface CalculatorInputs {
  symbol: string;
  capital: string;
  deployedCapital: string;
  deployedType: 'percent' | 'fixed';
  riskPercent: string;
  riskAmount: string;
  riskType: 'percent' | 'fixed';
  entryPrice: string;
  stopLoss: string;
  targetPrice: string;
  tradeDirection: 'LONG' | 'SHORT';
  useMaxBuyingPower: boolean;
  lotSize: string;
  expiryDate: string;
  marginPercent: string;
}

const FuturesCalculator = () => {
  const { toast } = useToast();
  const [isSaving, setIsSaving] = useState(false);
  const [appSettings, setAppSettings] = useState<AppSettings>(getSettings);
  
  // Listen for settings changes
  useEffect(() => {
    const handleSettingsChange = (e: CustomEvent<AppSettings>) => {
      setAppSettings(e.detail);
    };
    window.addEventListener("settingsChanged", handleSettingsChange as EventListener);
    return () => window.removeEventListener("settingsChanged", handleSettingsChange as EventListener);
  }, []);

  const [inputs, setInputs] = useState<CalculatorInputs>({
    symbol: "",
    capital: "100000",
    deployedCapital: "20",
    deployedType: 'percent',
    riskPercent: "1",
    riskAmount: "1000",
    riskType: 'percent',
    entryPrice: "",
    stopLoss: "",
    targetPrice: "",
    tradeDirection: 'LONG',
    useMaxBuyingPower: false,
    lotSize: "50",
    expiryDate: "",
    marginPercent: "15",
  });

  // handleWheel imported from formatters

  const saveToSheets = async () => {
    if (!appSettings.spreadsheetId) {
      toast({ title: "Error", description: "Please set Google Sheet ID in Settings", variant: "destructive" });
      return;
    }
    if (!calculations.isValid) {
      toast({ title: "Error", description: "Please fill in all trade details", variant: "destructive" });
      return;
    }

    setIsSaving(true);
    try {
      const { error } = await supabase.functions.invoke('sync-calculator', {
        body: {
          spreadsheetId: appSettings.spreadsheetId,
          type: 'futures',
          data: {
            date: new Date().toISOString().split('T')[0],
            symbol: inputs.symbol.toUpperCase() || 'N/A',
            tradeDirection: inputs.tradeDirection,
            capital: calculations.totalCapital,
            deployedCapital: calculations.deployedCapital,
            marginPercent: parseFloat(inputs.marginPercent),
            lotSize: parseInt(inputs.lotSize),
            entryPrice: parseFloat(inputs.entryPrice),
            stopLoss: parseFloat(inputs.stopLoss),
            targetPrice: parseFloat(inputs.targetPrice),
            lots: calculations.lots,
            quantity: calculations.quantity,
            contractValue: calculations.contractValue,
            marginRequired: calculations.marginRequired,
            riskAmount: calculations.riskAmount,
            potentialProfit: calculations.netProfit,
            riskRewardRatio: calculations.riskRewardRatio,
            totalCharges: calculations.totalCharges,
            expiryDate: inputs.expiryDate,
          }
        }
      });

      if (error) throw error;
      toast({ title: "Success", description: "Saved to Google Sheets!" });
    } catch (error) {
      console.error('Save error:', error);
      toast({ title: "Error", description: "Failed to save to sheets", variant: "destructive" });
    } finally {
      setIsSaving(false);
    }
  };

  const calculations = useMemo(() => {
    const totalCapital = parseFloat(inputs.capital) || 0;
    const deployedPercent = parseFloat(inputs.deployedCapital) || 0;
    const fixedDeployed = parseFloat(inputs.deployedCapital) || 0;
    const riskPercent = parseFloat(inputs.riskPercent) || 0;
    const fixedRisk = parseFloat(inputs.riskAmount) || 0;
    const entry = parseFloat(inputs.entryPrice) || 0;
    const sl = parseFloat(inputs.stopLoss) || 0;
    const target = parseFloat(inputs.targetPrice) || 0;
    const isLong = inputs.tradeDirection === 'LONG';
    const lotSize = parseInt(inputs.lotSize) || 1;
    const marginPercent = parseFloat(inputs.marginPercent) || 15;

    // Calculate deployed capital based on type
    const deployedCapital = inputs.deployedType === 'percent'
      ? (totalCapital * deployedPercent) / 100
      : fixedDeployed;

    // Calculate risk amount based on type
    const configuredRiskAmount = inputs.riskType === 'percent' 
      ? (deployedCapital * riskPercent) / 100 
      : fixedRisk;
    
    const riskPerShare = isLong ? entry - sl : sl - entry;
    const riskPerLot = riskPerShare * lotSize;
    
    // Calculate lots based on mode
    let lots: number;
    let wasLotsCapped = false;
    if (inputs.useMaxBuyingPower && entry > 0) {
      // Max buying power mode - based on margin available
      const marginPerLot = (entry * lotSize * marginPercent) / 100;
      lots = Math.floor(deployedCapital / marginPerLot);
    } else {
      // Risk-based mode
      const riskBasedLots = riskPerLot > 0 ? Math.floor(configuredRiskAmount / riskPerLot) : 0;
      // Cap lots so margin doesn't exceed deployed capital
      const marginPerLot = entry > 0 ? (entry * lotSize * marginPercent) / 100 : 0;
      const maxLotsByMargin = marginPerLot > 0 ? Math.floor(deployedCapital / marginPerLot) : 0;
      if (riskBasedLots > maxLotsByMargin && maxLotsByMargin > 0) {
        lots = maxLotsByMargin;
        wasLotsCapped = true;
      } else {
        lots = riskBasedLots;
      }
    }

    // Required deployed capital to achieve full risk (for capping warning)
    const requiredDeployedCapital = riskPerLot > 0 && entry > 0
      ? Math.ceil((configuredRiskAmount / riskPerLot) * (entry * lotSize * marginPercent) / 100)
      : 0;
    
    const quantity = lots * lotSize;
    const contractValue = quantity * entry;
    const marginRequired = (contractValue * marginPercent) / 100;
    
    // Actual risk amount based on position (use actual lots, not configured risk when capped)
    const riskAmount = wasLotsCapped ? lots * riskPerLot : (inputs.useMaxBuyingPower ? lots * riskPerLot : configuredRiskAmount);
    
    const rewardPerShare = isLong ? target - entry : entry - target;
    const potentialProfit = quantity * rewardPerShare;
    const riskRewardRatio = riskPerShare > 0 ? rewardPerShare / riskPerShare : 0;
    
    // % moves from entry
    const slPercent = entry > 0 ? Math.abs((entry - sl) / entry) * 100 : 0;
    const targetPercent = entry > 0 ? Math.abs((target - entry) / entry) * 100 : 0;
    
    // Capital % at risk
    const capitalAtRiskPercent = totalCapital > 0 ? (riskAmount / totalCapital) * 100 : 0;
    
    // Margin exceeds deployed capital warning
    const exceedsCapital = marginRequired > deployedCapital;
    
    // Trailing SL levels (1R, 2R, 3R moves)
    const trailingSLLevels = isLong ? {
      costToEntry: entry,
      oneR: entry + riskPerShare,
      twoR: entry + (riskPerShare * 2),
      threeR: entry + (riskPerShare * 3),
    } : {
      costToEntry: entry,
      oneR: entry - riskPerShare,
      twoR: entry - (riskPerShare * 2),
      threeR: entry - (riskPerShare * 3),
    };
    
    // Futures charges
    const charges = calculateCharges(contractValue, 'futures');
    const totalCharges = charges.total;
    const netProfit = potentialProfit - totalCharges;
    const actualLoss = riskAmount + totalCharges;

    // Validate trade setup
    const isValidSetup = isLong 
      ? (entry > sl && target > entry)
      : (sl > entry && entry > target);

    return {
      riskAmount,
      lots,
      quantity,
      contractValue,
      marginRequired,
      potentialProfit,
      riskRewardRatio,
      totalCharges,
      netProfit,
      actualLoss,
      isLong,
      isValid: entry > 0 && sl > 0 && target > 0 && lots > 0 && isValidSetup,
      riskPerShare,
      riskPerLot,
      deployedCapital,
      slPercent,
      targetPercent,
      capitalAtRiskPercent,
      exceedsCapital,
      wasLotsCapped,
      requiredDeployedCapital,
      trailingSLLevels,
      totalCapital,
      lotSize,
    };
  }, [inputs]);

  const handleChange = (field: keyof CalculatorInputs) => (e: React.ChangeEvent<HTMLInputElement>) => {
    setInputs(prev => ({ ...prev, [field]: e.target.value }));
  };

  // formatCurrency and formatNumber imported from @/lib/formatters

  return (
    <div className="grid lg:grid-cols-2 gap-6">
      {/* Input Section */}
      <div className="space-y-6">
        {/* Capital & Risk Card */}
        <div className="glass rounded-xl p-6 space-y-5">
          <div className="flex items-center gap-2 text-primary mb-4">
            <Shield className="w-5 h-5" />
            <h2 className="font-semibold text-lg">Capital & Risk Settings</h2>
          </div>
          
          <div className="space-y-4">
            <div className="space-y-2">
              <Label className="text-muted-foreground flex items-center gap-2">
                <IndianRupee className="w-4 h-4" />
                Total Capital
              </Label>
              <p className="text-[11px] text-muted-foreground/70 -mt-1">Your total trading account balance</p>
              <Input
                type="number"
                value={inputs.capital}
                onChange={handleChange("capital")}
                onWheel={handleWheel}
                placeholder="100000"
              />
            </div>
            
            {/* Deployed Capital */}
            <div className="space-y-2">
              <Label className="text-muted-foreground">Capital Allocation</Label>
              <p className="text-[11px] text-muted-foreground/70 -mt-1">How much of your capital to deploy in this trade</p>
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => setInputs(prev => ({ ...prev, deployedType: 'percent' }))}
                  className={`h-10 rounded-lg font-medium text-sm transition-all flex items-center justify-center gap-1 ${
                    inputs.deployedType === 'percent'
                      ? 'bg-primary text-primary-foreground'
                      : 'bg-secondary text-muted-foreground hover:bg-secondary/80'
                  }`}
                >
                  <Percent className="w-3 h-3" />
                  Percentage
                </button>
                <button
                  onClick={() => setInputs(prev => ({ ...prev, deployedType: 'fixed' }))}
                  className={`h-10 rounded-lg font-medium text-sm transition-all flex items-center justify-center gap-1 ${
                    inputs.deployedType === 'fixed'
                      ? 'bg-primary text-primary-foreground'
                      : 'bg-secondary text-muted-foreground hover:bg-secondary/80'
                  }`}
                >
                  <IndianRupee className="w-3 h-3" />
                  Fixed Amount
                </button>
              </div>
            </div>
            
            {inputs.deployedType === 'percent' ? (
              <div className="space-y-2">
                <Label className="text-muted-foreground flex items-center gap-2">
                  <Percent className="w-4 h-4" />
                  Deploy % of Capital
                </Label>
                <p className="text-[11px] text-muted-foreground/70 -mt-1">e.g., 20% of ₹1L = ₹20,000 deployed</p>
                <Input
                  type="number"
                  value={inputs.deployedCapital}
                  onChange={handleChange("deployedCapital")}
                  onWheel={handleWheel}
                  placeholder="20"
                  step="5"
                />
              </div>
            ) : (
              <div className="space-y-2">
                <Label className="text-muted-foreground flex items-center gap-2">
                  <IndianRupee className="w-4 h-4" />
                  Deploy Amount (₹)
                </Label>
                <p className="text-[11px] text-muted-foreground/70 -mt-1">Fixed rupee amount to use for this trade</p>
                <Input
                  type="number"
                  value={inputs.deployedCapital}
                  onChange={handleChange("deployedCapital")}
                  onWheel={handleWheel}
                  placeholder="20000"
                />
              </div>
            )}
            
            {/* Position Sizing Mode */}
            <div className="space-y-2">
              <Label className="text-muted-foreground">Position Sizing Mode</Label>
              <p className="text-[11px] text-muted-foreground/70 -mt-1">Risk-Based = size by SL risk; Max Margin = use full margin</p>
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => setInputs(prev => ({ ...prev, useMaxBuyingPower: false }))}
                  className={`h-10 rounded-lg font-medium text-sm transition-all flex items-center justify-center gap-1 ${
                    !inputs.useMaxBuyingPower
                      ? 'bg-primary text-primary-foreground'
                      : 'bg-secondary text-muted-foreground hover:bg-secondary/80'
                  }`}
                >
                  <Shield className="w-3 h-3" />
                  Risk-Based
                </button>
                <button
                  onClick={() => setInputs(prev => ({ ...prev, useMaxBuyingPower: true }))}
                  className={`h-10 rounded-lg font-medium text-sm transition-all flex items-center justify-center gap-1 ${
                    inputs.useMaxBuyingPower
                      ? 'bg-primary text-primary-foreground'
                      : 'bg-secondary text-muted-foreground hover:bg-secondary/80'
                  }`}
                >
                  <TrendingUp className="w-3 h-3" />
                  Max Margin
                </button>
              </div>
            </div>
            
            {!inputs.useMaxBuyingPower && (
              <>
                <div className="space-y-2">
                  <Label className="text-muted-foreground">Risk Type</Label>
                  <p className="text-[11px] text-muted-foreground/70 -mt-1">Define risk as % of capital or fixed ₹ amount</p>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => setInputs(prev => ({ ...prev, riskType: 'percent' }))}
                      className={`h-10 rounded-lg font-medium text-sm transition-all flex items-center justify-center gap-1 ${
                        inputs.riskType === 'percent'
                          ? 'bg-primary text-primary-foreground'
                          : 'bg-secondary text-muted-foreground hover:bg-secondary/80'
                      }`}
                    >
                      <Percent className="w-3 h-3" />
                      Percentage
                    </button>
                    <button
                      onClick={() => setInputs(prev => ({ ...prev, riskType: 'fixed' }))}
                      className={`h-10 rounded-lg font-medium text-sm transition-all flex items-center justify-center gap-1 ${
                        inputs.riskType === 'fixed'
                          ? 'bg-primary text-primary-foreground'
                          : 'bg-secondary text-muted-foreground hover:bg-secondary/80'
                      }`}
                    >
                      <IndianRupee className="w-3 h-3" />
                      Fixed Amount
                    </button>
                  </div>
                </div>
                
                {inputs.riskType === 'percent' ? (
                  <div className="space-y-2">
                    <Label className="text-muted-foreground flex items-center gap-2">
                      <Percent className="w-4 h-4" />
                      Risk Per Trade (%)
                    </Label>
                    <p className="text-[11px] text-muted-foreground/70 -mt-1">Max % of capital to risk (recommended: 1-2%)</p>
                    <Input
                      type="number"
                      value={inputs.riskPercent}
                      onChange={handleChange("riskPercent")}
                      onWheel={handleWheel}
                      placeholder="1"
                      step="0.1"
                    />
                  </div>
                ) : (
                  <div className="space-y-2">
                    <Label className="text-muted-foreground flex items-center gap-2">
                      <IndianRupee className="w-4 h-4" />
                      Risk Amount (₹)
                    </Label>
                    <p className="text-[11px] text-muted-foreground/70 -mt-1">Max rupees willing to lose on this trade</p>
                    <Input
                      type="number"
                      value={inputs.riskAmount}
                      onChange={handleChange("riskAmount")}
                      onWheel={handleWheel}
                      placeholder="1000"
                    />
                  </div>
                )}
              </>
            )}
          </div>
        </div>

        {/* Trade Details Card */}
        <div className="glass rounded-xl p-6 space-y-5">
          <div className="flex items-center gap-2 text-primary mb-4">
            <Target className="w-5 h-5" />
            <h2 className="font-semibold text-lg">Futures Trade Setup</h2>
          </div>

          {/* Trade Direction Toggle */}
          <div className="space-y-2">
            <Label className="text-muted-foreground">Trade Direction</Label>
            <p className="text-[11px] text-muted-foreground/70 -mt-1">Long = expect price to rise; Short = expect price to fall</p>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => setInputs(prev => ({ ...prev, tradeDirection: 'LONG' }))}
                className={`h-12 rounded-lg font-semibold transition-all flex items-center justify-center gap-2 ${
                  inputs.tradeDirection === 'LONG'
                    ? 'bg-success text-success-foreground'
                    : 'bg-secondary text-muted-foreground hover:bg-secondary/80'
                }`}
              >
                <TrendingUp className="w-4 h-4" />
                BUY (Long)
              </button>
              <button
                onClick={() => setInputs(prev => ({ ...prev, tradeDirection: 'SHORT' }))}
                className={`h-12 rounded-lg font-semibold transition-all flex items-center justify-center gap-2 ${
                  inputs.tradeDirection === 'SHORT'
                    ? 'bg-destructive text-destructive-foreground'
                    : 'bg-secondary text-muted-foreground hover:bg-secondary/80'
                }`}
              >
                <TrendingDown className="w-4 h-4" />
                SELL (Short)
              </button>
            </div>
          </div>
          
          <div className="space-y-4">
            <div className="space-y-2">
              <Label className="text-muted-foreground">Symbol</Label>
              <p className="text-[11px] text-muted-foreground/70 -mt-1">Futures contract ticker (e.g., NIFTY, BANKNIFTY)</p>
              <Input
                type="text"
                value={inputs.symbol}
                onChange={handleChange("symbol")}
                placeholder="e.g., NIFTY, BANKNIFTY, RELIANCE"
                className="uppercase"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-muted-foreground">Lot Size</Label>
                <p className="text-[11px] text-muted-foreground/70 -mt-1">Units per lot for this contract</p>
                <Input
                  type="number"
                  value={inputs.lotSize}
                  onChange={handleChange("lotSize")}
                  onWheel={handleWheel}
                  placeholder="50"
                />
              </div>
              <div className="space-y-2">
                <Label className="text-muted-foreground">Margin % Required</Label>
                <p className="text-[11px] text-muted-foreground/70 -mt-1">Broker's margin requirement (e.g., NIFTY ~12-15%)</p>
                <Input
                  type="number"
                  value={inputs.marginPercent}
                  onChange={handleChange("marginPercent")}
                  onWheel={handleWheel}
                  placeholder="15"
                  step="0.5"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label className="text-muted-foreground flex items-center gap-2">
                <Calendar className="w-4 h-4" />
                Expiry Date
              </Label>
              <p className="text-[11px] text-muted-foreground/70 -mt-1">Contract expiry date (usually last Thursday of month)</p>
              <Input
                type="date"
                value={inputs.expiryDate}
                onChange={handleChange("expiryDate")}
              />
            </div>

            <div className="space-y-2">
              <Label className="text-muted-foreground">Entry Price (₹)</Label>
              <p className="text-[11px] text-muted-foreground/70 -mt-1">Price at which you plan to enter the trade</p>
              <Input
                type="number"
                value={inputs.entryPrice}
                onChange={handleChange("entryPrice")}
                onWheel={handleWheel}
                placeholder="Enter entry price"
                step="0.05"
              />
            </div>
            
            <div className="space-y-2">
              <Label className="text-muted-foreground flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-destructive" />
                Stop Loss (₹) {inputs.tradeDirection === 'LONG' ? '(Below Entry)' : '(Above Entry)'}
              </Label>
              <p className="text-[11px] text-muted-foreground/70 -mt-1">Exit price to limit your loss if trade goes wrong</p>
              <Input
                type="number"
                value={inputs.stopLoss}
                onChange={handleChange("stopLoss")}
                onWheel={handleWheel}
                placeholder="Enter stop loss"
                step="0.05"
              />
            </div>
            
            <div className="space-y-2">
              <Label className="text-muted-foreground flex items-center gap-2">
                <Target className="w-4 h-4 text-success" />
                Target Price (₹) {inputs.tradeDirection === 'LONG' ? '(Above Entry)' : '(Below Entry)'}
              </Label>
              <p className="text-[11px] text-muted-foreground/70 -mt-1">Exit price to book profit when trade goes your way</p>
              <Input
                type="number"
                value={inputs.targetPrice}
                onChange={handleChange("targetPrice")}
                onWheel={handleWheel}
                placeholder="Enter target price"
                step="0.05"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Save to Google Sheets */}
      <div className="glass rounded-xl p-4 sm:p-6 mt-6 sticky top-0 z-30 md:static md:z-auto">
        <div className="flex items-center gap-2 text-primary mb-4">
          <Save className="w-5 h-5" />
          <h2 className="font-semibold text-lg">Save & Send Alert</h2>
        </div>
        <div className="flex flex-col sm:flex-row gap-3 items-center">
          <div className="flex-1 text-sm text-muted-foreground">
            {appSettings.spreadsheetId ? (
              <span className="text-success">✓ Sheet ID configured in Settings</span>
            ) : (
              <span className="text-warning">⚠ Configure Sheet ID in Settings (⚙️ icon)</span>
            )}
          </div>
          <Button 
            onClick={saveToSheets} 
            disabled={isSaving || !calculations.isValid || !appSettings.spreadsheetId}
            className="gap-2 bg-primary hover:bg-primary/90"
          >
            {isSaving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
            {isSaving ? 'Saving...' : 'Save & Send'}
          </Button>
        </div>
        <p className="text-xs text-muted-foreground mt-2">
          Saves to "Futures Calculator" sheet and sends Telegram alert.
        </p>
      </div>

      {/* Results Section */}
      <div className="space-y-6">
        {/* Position Size Results */}
        <div className="glass rounded-xl p-6">
           <h3 className="text-lg font-semibold text-foreground mb-4">Position Size</h3>
          {calculations.wasLotsCapped && (
            <div className="flex items-start gap-2 p-3 rounded-lg bg-warning/10 border border-warning/30 mb-4">
              <AlertTriangle className="w-4 h-4 text-warning shrink-0 mt-0.5" />
              <div className="flex-1">
                <p className="text-sm text-warning">
                  Lots capped to fit deployed capital. Need {formatCurrency(calculations.requiredDeployedCapital)} deployed capital for full risk.
                </p>
                <Button
                  variant="outline"
                  size="sm"
                  className="mt-2 h-7 text-xs border-warning/50 text-warning hover:bg-warning/10"
                  onClick={() => {
                    const required = calculations.requiredDeployedCapital;
                    if (inputs.deployedType === 'percent') {
                      const percent = calculations.totalCapital > 0 ? ((required / calculations.totalCapital) * 100).toFixed(1) : '0';
                      setInputs(prev => ({ ...prev, deployedCapital: percent }));
                    } else {
                      setInputs(prev => ({ ...prev, deployedCapital: String(required) }));
                    }
                    toast({ title: "Capital Adjusted", description: `Deployed capital set to ${formatCurrency(required)}` });
                  }}
                >
                  Auto-adjust to {formatCurrency(calculations.requiredDeployedCapital)}
                </Button>
              </div>
            </div>
          )}
          <div className="space-y-4">
            <div className="flex justify-between items-center py-2 border-b border-border/50">
              <span className="text-muted-foreground">Deployed Capital</span>
              <span className="font-mono text-foreground">{formatCurrency(calculations.deployedCapital)}</span>
            </div>
            <div className="flex justify-between items-center py-2 border-b border-border/50">
              <span className="text-muted-foreground">Lots</span>
              <span className="font-mono text-xl font-bold text-primary">{calculations.lots}</span>
            </div>
            <div className="flex justify-between items-center py-2 border-b border-border/50">
              <span className="text-muted-foreground">Quantity</span>
              <span className="font-mono text-foreground">{calculations.quantity}</span>
            </div>
            <div className="flex justify-between items-center py-2 border-b border-border/50">
              <span className="text-muted-foreground">Contract Value</span>
              <span className="font-mono text-foreground">{formatCurrency(calculations.contractValue)}</span>
            </div>
            <div className="flex justify-between items-center py-2">
              <span className="text-muted-foreground">Margin Required</span>
              <span className="font-mono text-foreground">{formatCurrency(calculations.marginRequired)}</span>
            </div>
          </div>
        </div>

        {/* Risk & Reward */}
        <div className="glass rounded-xl p-6">
          <h3 className="text-lg font-semibold text-foreground mb-4">Risk & Reward</h3>
          <div className="space-y-4">
            <div className="flex justify-between items-center py-2 border-b border-border/50">
              <span className="text-muted-foreground">Risk Per Lot</span>
              <span className="font-mono text-destructive">{formatCurrency(calculations.riskPerLot)}</span>
            </div>
            <div className="flex justify-between items-center py-2 border-b border-border/50">
              <span className="text-muted-foreground">Total Risk Amount</span>
              <span className="font-mono text-destructive">{formatCurrency(calculations.riskAmount)}</span>
            </div>
            <div className="flex justify-between items-center py-2 border-b border-border/50">
              <span className="text-muted-foreground">Potential Profit</span>
              <span className="font-mono text-success">{formatCurrency(calculations.potentialProfit)}</span>
            </div>
            <div className="flex justify-between items-center py-2 border-b border-border/50">
              <span className="text-muted-foreground">Net Profit (after charges)</span>
              <span className="font-mono text-success">{formatCurrency(calculations.netProfit)}</span>
            </div>
            <div className="flex justify-between items-center py-2">
              <span className="text-muted-foreground">Risk : Reward Ratio</span>
              <span className={`font-mono text-lg font-bold ${calculations.riskRewardRatio >= 2 ? 'text-success' : calculations.riskRewardRatio >= 1 ? 'text-warning' : 'text-destructive'}`}>
                1 : {formatNumber(calculations.riskRewardRatio)}
              </span>
            </div>
          </div>
        </div>

        {/* Margin Warning */}
        {calculations.exceedsCapital && (
          <div className="glass rounded-xl p-6 border-2 border-destructive/50 bg-destructive/10">
            <div className="flex items-center gap-2 text-destructive mb-2">
              <AlertTriangle className="w-5 h-5" />
              <h3 className="font-semibold">Margin Warning</h3>
            </div>
            <p className="text-muted-foreground text-sm">
              Margin required ({formatCurrency(calculations.marginRequired)}) exceeds deployed capital ({formatCurrency(calculations.deployedCapital)}).
              Reduce position size or increase capital allocation.
            </p>
          </div>
        )}

        {/* % Moves & Capital at Risk */}
        <div className="glass rounded-xl p-6">
          <h3 className="text-lg font-semibold text-foreground mb-4">% Moves & Capital at Risk</h3>
          <div className="space-y-4">
            <div className="flex justify-between items-center py-2 border-b border-border/50">
              <span className="text-muted-foreground">Entry → SL Move</span>
              <span className="font-mono text-destructive">-{formatNumber(calculations.slPercent)}%</span>
            </div>
            <div className="flex justify-between items-center py-2 border-b border-border/50">
              <span className="text-muted-foreground">Entry → Target Move</span>
              <span className="font-mono text-success">+{formatNumber(calculations.targetPercent)}%</span>
            </div>
            <div className="flex justify-between items-center py-2">
              <span className="text-muted-foreground">Capital % at Risk</span>
              <span className={`font-mono font-bold ${calculations.capitalAtRiskPercent <= 2 ? 'text-success' : calculations.capitalAtRiskPercent <= 5 ? 'text-warning' : 'text-destructive'}`}>
                {formatNumber(calculations.capitalAtRiskPercent)}%
              </span>
            </div>
          </div>
        </div>

        {/* Trailing SL Levels */}
        <div className="glass rounded-xl p-6">
          <h3 className="text-lg font-semibold text-foreground mb-4">Trailing SL Levels</h3>
          <div className="space-y-4">
            <div className="flex justify-between items-center py-2 border-b border-border/50">
              <span className="text-muted-foreground">Cost to Entry</span>
              <span className="font-mono text-foreground">₹{formatNumber(calculations.trailingSLLevels.costToEntry)}</span>
            </div>
            <div className="flex justify-between items-center py-2 border-b border-border/50">
              <span className="text-muted-foreground">1R ({calculations.isLong ? 'Trail to Entry' : 'Trail to Entry'})</span>
              <span className="font-mono text-success">₹{formatNumber(calculations.trailingSLLevels.oneR)}</span>
            </div>
            <div className="flex justify-between items-center py-2 border-b border-border/50">
              <span className="text-muted-foreground">2R (Lock 1R Profit)</span>
              <span className="font-mono text-success">₹{formatNumber(calculations.trailingSLLevels.twoR)}</span>
            </div>
            <div className="flex justify-between items-center py-2">
              <span className="text-muted-foreground">3R (Lock 2R Profit)</span>
              <span className="font-mono text-success">₹{formatNumber(calculations.trailingSLLevels.threeR)}</span>
            </div>
          </div>
        </div>

        {/* Estimated Charges */}
        <div className="glass rounded-xl p-6">
          <h3 className="text-lg font-semibold text-foreground mb-4">Estimated Charges</h3>
          <div className="space-y-4">
            <div className="flex justify-between items-center py-2 border-b border-border/50">
              <span className="text-muted-foreground">Total Charges</span>
              <span className="font-mono text-foreground">{formatCurrency(calculations.totalCharges)}</span>
            </div>
            <div className="flex justify-between items-center py-2">
              <span className="text-muted-foreground">Actual Loss (if SL hit)</span>
              <span className="font-mono text-destructive">{formatCurrency(calculations.actualLoss)}</span>
            </div>
          </div>
        </div>
      </div>

    </div>
  );
};

export default FuturesCalculator;
