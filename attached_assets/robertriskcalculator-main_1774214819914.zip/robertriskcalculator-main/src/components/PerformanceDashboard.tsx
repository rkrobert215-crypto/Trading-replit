import { useState, useEffect, useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { 
  TrendingUp, TrendingDown, Target, Award, 
  BarChart3, PieChart, Activity, Loader2, Download, FileText
} from "lucide-react";
import {
  LineChart, Line, AreaChart, Area, BarChart, Bar,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart as RechartsPieChart, Pie, Cell, Legend
} from "recharts";
import type { Trade } from "@/types/trade";
import { formatCurrency } from "@/lib/formatters";

interface DailyPnL {
  date: string;
  pnl: number;
  cumulative: number;
  trades: number;
}

interface WeeklyStats {
  week: string;
  winRate: number;
  trades: number;
  pnl: number;
}

interface InstrumentStats {
  name: string;
  trades: number;
  pnl: number;
  winRate: number;
}

const CHART_COLORS = {
  profit: 'hsl(var(--success))',
  loss: 'hsl(var(--destructive))',
  primary: 'hsl(var(--primary))',
  secondary: 'hsl(var(--secondary))',
  border: 'hsl(var(--border))',
  muted: 'hsl(var(--muted-foreground))',
};

const PIE_COLORS = ['hsl(var(--primary))', 'hsl(var(--success))', 'hsl(var(--warning))', 'hsl(280, 65%, 60%)'];

export const PerformanceDashboard = () => {
  const [trades, setTrades] = useState<Trade[]>([]);
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();

  useEffect(() => {
    if (user) {
      fetchTrades();
    } else {
      setLoading(false);
    }
  }, [user]);

  const fetchTrades = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('trades')
      .select('*')
      .eq('status', 'CLOSED')
      .order('trade_date', { ascending: true });
    
    if (!error && data) {
      setTrades(data as Trade[]);
    }
    setLoading(false);
  };

  const stats = useMemo(() => {
    if (trades.length === 0) return null;

    const winningTrades = trades.filter(t => (t.net_pnl || 0) > 0);
    const losingTrades = trades.filter(t => (t.net_pnl || 0) < 0);
    
    const totalPnL = trades.reduce((sum, t) => sum + (t.net_pnl || 0), 0);
    const totalGrossPnL = trades.reduce((sum, t) => sum + (t.gross_pnl || 0), 0);
    const totalCharges = trades.reduce((sum, t) => sum + (t.charges || 0), 0);
    
    const wins = winningTrades.map(t => t.net_pnl || 0);
    const losses = losingTrades.map(t => Math.abs(t.net_pnl || 0));
    
    const avgWin = wins.length > 0 ? wins.reduce((a, b) => a + b, 0) / wins.length : 0;
    const avgLoss = losses.length > 0 ? losses.reduce((a, b) => a + b, 0) / losses.length : 0;
    const largestWin = wins.length > 0 ? Math.max(...wins) : 0;
    const largestLoss = losses.length > 0 ? Math.max(...losses) : 0;
    
    const totalWins = wins.reduce((a, b) => a + b, 0);
    const totalLosses = losses.reduce((a, b) => a + b, 0);
    const profitFactor = totalLosses > 0 ? totalWins / totalLosses : totalWins > 0 ? Infinity : 0;
    
    const avgRR = trades
      .filter(t => t.risk_reward_ratio != null)
      .reduce((sum, t, _, arr) => sum + (t.risk_reward_ratio || 0) / arr.length, 0);

    return {
      totalTrades: trades.length,
      winningTrades: winningTrades.length,
      losingTrades: losingTrades.length,
      winRate: (winningTrades.length / trades.length) * 100,
      totalPnL,
      totalGrossPnL,
      totalCharges,
      avgWin,
      avgLoss,
      largestWin,
      largestLoss,
      profitFactor,
      avgRR,
      expectancy: avgWin * (winningTrades.length / trades.length) - avgLoss * (losingTrades.length / trades.length),
    };
  }, [trades]);

  const dailyPnL = useMemo((): DailyPnL[] => {
    if (trades.length === 0) return [];

    const grouped = trades.reduce((acc, trade) => {
      const date = trade.trade_date;
      if (!acc[date]) {
        acc[date] = { pnl: 0, trades: 0 };
      }
      acc[date].pnl += trade.net_pnl || 0;
      acc[date].trades += 1;
      return acc;
    }, {} as Record<string, { pnl: number; trades: number }>);

    let cumulative = 0;
    return Object.entries(grouped)
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([date, data]) => {
        cumulative += data.pnl;
        return {
          date: new Date(date).toLocaleDateString('en-IN', { day: '2-digit', month: 'short' }),
          pnl: data.pnl,
          cumulative,
          trades: data.trades,
        };
      });
  }, [trades]);

  const weeklyStats = useMemo((): WeeklyStats[] => {
    if (trades.length === 0) return [];

    const grouped = trades.reduce((acc, trade) => {
      const date = new Date(trade.trade_date);
      const weekStart = new Date(date);
      weekStart.setDate(date.getDate() - date.getDay());
      const weekKey = weekStart.toISOString().split('T')[0];
      
      if (!acc[weekKey]) {
        acc[weekKey] = { trades: [], pnl: 0 };
      }
      acc[weekKey].trades.push(trade);
      acc[weekKey].pnl += trade.net_pnl || 0;
      return acc;
    }, {} as Record<string, { trades: Trade[]; pnl: number }>);

    return Object.entries(grouped)
      .sort(([a], [b]) => a.localeCompare(b))
      .slice(-12) // Last 12 weeks
      .map(([week, data]) => {
        const wins = data.trades.filter(t => (t.net_pnl || 0) > 0).length;
        return {
          week: new Date(week).toLocaleDateString('en-IN', { day: '2-digit', month: 'short' }),
          winRate: (wins / data.trades.length) * 100,
          trades: data.trades.length,
          pnl: data.pnl,
        };
      });
  }, [trades]);

  const instrumentStats = useMemo((): InstrumentStats[] => {
    if (trades.length === 0) return [];

    const grouped = trades.reduce((acc, trade) => {
      const key = trade.instrument;
      if (!acc[key]) {
        acc[key] = { trades: [], pnl: 0 };
      }
      acc[key].trades.push(trade);
      acc[key].pnl += trade.net_pnl || 0;
      return acc;
    }, {} as Record<string, { trades: Trade[]; pnl: number }>);

    return Object.entries(grouped).map(([name, data]) => {
      const wins = data.trades.filter(t => (t.net_pnl || 0) > 0).length;
      return {
        name,
        trades: data.trades.length,
        pnl: data.pnl,
        winRate: (wins / data.trades.length) * 100,
      };
    });
  }, [trades]);

  // formatCurrency imported from @/lib/formatters

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (trades.length === 0) {
    return (
      <div className="glass rounded-xl p-8 text-center">
        <BarChart3 className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
        <h3 className="text-lg font-semibold text-foreground mb-2">No Closed Trades Yet</h3>
        <p className="text-muted-foreground">
          Close some trades in the Journal tab to see your performance analytics.
        </p>
      </div>
    );
  }

  const exportDashboardReport = () => {
    if (!stats) return;
    const lines = [
      `TRADING PERFORMANCE REPORT`,
      `Generated: ${new Date().toLocaleDateString('en-IN', { day: '2-digit', month: 'long', year: 'numeric' })}`,
      ``,
      `=== OVERVIEW ===`,
      `Total Trades: ${stats.totalTrades}`,
      `Winning: ${stats.winningTrades} | Losing: ${stats.losingTrades}`,
      `Win Rate: ${stats.winRate.toFixed(1)}%`,
      ``,
      `=== P&L SUMMARY ===`,
      `Net P&L: ${formatCurrency(stats.totalPnL)}`,
      `Gross P&L: ${formatCurrency(stats.totalGrossPnL)}`,
      `Total Charges: ${formatCurrency(stats.totalCharges)}`,
      ``,
      `=== STATISTICS ===`,
      `Avg Win: ${formatCurrency(stats.avgWin)}`,
      `Avg Loss: ${formatCurrency(stats.avgLoss)}`,
      `Largest Win: ${formatCurrency(stats.largestWin)}`,
      `Largest Loss: ${formatCurrency(stats.largestLoss)}`,
      `Profit Factor: ${stats.profitFactor === Infinity ? '∞' : stats.profitFactor.toFixed(2)}`,
      `Expectancy: ${formatCurrency(stats.expectancy)}`,
      `Avg R:R: ${stats.avgRR.toFixed(2)}`,
      `Win/Loss Ratio: ${stats.avgLoss ? (stats.avgWin / stats.avgLoss).toFixed(2) : '∞'}`,
      ``,
      `=== INSTRUMENT BREAKDOWN ===`,
      ...instrumentStats.map(i => `${i.name}: ${i.trades} trades | WR: ${i.winRate.toFixed(0)}% | P&L: ${formatCurrency(i.pnl)}`),
      ``,
      `=== DAILY P&L ===`,
      `Date, P&L, Cumulative, Trades`,
      ...dailyPnL.map(d => `${d.date}, ${formatCurrency(d.pnl)}, ${formatCurrency(d.cumulative)}, ${d.trades}`),
    ];

    const blob = new Blob([lines.join('\n')], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `performance_report_${new Date().toISOString().split('T')[0]}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* Header with Export */}
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold text-foreground">Performance Analytics</h2>
        <Button variant="outline" size="sm" onClick={exportDashboardReport} className="gap-2">
          <FileText className="h-4 w-4" />
          <span className="hidden sm:inline">Export</span> Report
        </Button>
      </div>

      {/* Key Stats Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-4">
        <Card className="glass border-border/50">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 text-muted-foreground mb-1">
              <Target className="h-4 w-4" />
              <span className="text-xs">Win Rate</span>
            </div>
            <p className="text-2xl font-mono font-bold text-primary">
              {stats?.winRate.toFixed(1)}%
            </p>
            <p className="text-xs text-muted-foreground">
              {stats?.winningTrades}W / {stats?.losingTrades}L
            </p>
          </CardContent>
        </Card>

        <Card className="glass border-border/50">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 text-muted-foreground mb-1">
              {(stats?.totalPnL || 0) >= 0 ? (
                <TrendingUp className="h-4 w-4 text-success" />
              ) : (
                <TrendingDown className="h-4 w-4 text-destructive" />
              )}
              <span className="text-xs">Total P&L</span>
            </div>
            <p className={`text-2xl font-mono font-bold ${(stats?.totalPnL || 0) >= 0 ? 'text-success' : 'text-destructive'}`}>
              {formatCurrency(stats?.totalPnL || 0)}
            </p>
            <p className="text-xs text-muted-foreground">
              Charges: {formatCurrency(stats?.totalCharges || 0)}
            </p>
          </CardContent>
        </Card>

        <Card className="glass border-border/50">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 text-muted-foreground mb-1">
              <Award className="h-4 w-4" />
              <span className="text-xs">Profit Factor</span>
            </div>
            <p className="text-2xl font-mono font-bold text-primary">
              {stats?.profitFactor === Infinity ? '∞' : stats?.profitFactor.toFixed(2)}
            </p>
            <p className="text-xs text-muted-foreground">
              Expectancy: {formatCurrency(stats?.expectancy || 0)}
            </p>
          </CardContent>
        </Card>

        <Card className="glass border-border/50">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 text-muted-foreground mb-1">
              <Activity className="h-4 w-4" />
              <span className="text-xs">Avg Win/Loss</span>
            </div>
            <p className="text-lg font-mono">
              <span className="text-success">{formatCurrency(stats?.avgWin || 0)}</span>
              <span className="text-muted-foreground mx-1">/</span>
              <span className="text-destructive">{formatCurrency(stats?.avgLoss || 0)}</span>
            </p>
            <p className="text-xs text-muted-foreground">
              {stats?.totalTrades} total trades
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Charts Row */}
      <div className="grid lg:grid-cols-2 gap-6">
        {/* Cumulative P&L Chart */}
        <Card className="glass border-border/50">
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-primary" />
              Cumulative P&L
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-48 sm:h-64">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={dailyPnL}>
                  <defs>
                    <linearGradient id="pnlGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor={CHART_COLORS.primary} stopOpacity={0.3} />
                      <stop offset="95%" stopColor={CHART_COLORS.primary} stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke={CHART_COLORS.border} />
                  <XAxis 
                    dataKey="date" 
                    stroke={CHART_COLORS.muted} 
                    fontSize={11}
                    tickLine={false}
                  />
                  <YAxis 
                    stroke={CHART_COLORS.muted} 
                    fontSize={11}
                    tickLine={false}
                    tickFormatter={(value) => `₹${(value / 1000).toFixed(0)}k`}
                  />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'hsl(var(--card))', 
                      border: '1px solid hsl(var(--border))',
                      borderRadius: '8px',
                    }}
                    formatter={(value: number) => [formatCurrency(value), 'Cumulative P&L']}
                  />
                  <Area 
                    type="monotone" 
                    dataKey="cumulative" 
                    stroke={CHART_COLORS.primary} 
                    fill="url(#pnlGradient)"
                    strokeWidth={2}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Daily P&L Bar Chart */}
        <Card className="glass border-border/50">
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <BarChart3 className="h-4 w-4 text-primary" />
              Daily P&L
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-48 sm:h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={dailyPnL}>
                  <CartesianGrid strokeDasharray="3 3" stroke={CHART_COLORS.border} />
                  <XAxis 
                    dataKey="date" 
                    stroke={CHART_COLORS.muted} 
                    fontSize={11}
                    tickLine={false}
                  />
                  <YAxis 
                    stroke={CHART_COLORS.muted} 
                    fontSize={11}
                    tickLine={false}
                    tickFormatter={(value) => `₹${(value / 1000).toFixed(0)}k`}
                  />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'hsl(var(--card))', 
                      border: '1px solid hsl(var(--border))',
                      borderRadius: '8px',
                    }}
                    formatter={(value: number, name: string) => [
                      formatCurrency(value), 
                      name === 'pnl' ? 'P&L' : name
                    ]}
                  />
                  <Bar 
                    dataKey="pnl" 
                    fill={CHART_COLORS.primary}
                    radius={[4, 4, 0, 0]}
                  />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Second Charts Row */}
      <div className="grid lg:grid-cols-2 gap-6">
        {/* Weekly Win Rate Trend */}
        <Card className="glass border-border/50">
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <Target className="h-4 w-4 text-primary" />
              Weekly Win Rate Trend
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-48 sm:h-64">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={weeklyStats}>
                  <CartesianGrid strokeDasharray="3 3" stroke={CHART_COLORS.border} />
                  <XAxis 
                    dataKey="week" 
                    stroke={CHART_COLORS.muted} 
                    fontSize={11}
                    tickLine={false}
                  />
                  <YAxis 
                    stroke={CHART_COLORS.muted} 
                    fontSize={11}
                    tickLine={false}
                    domain={[0, 100]}
                    tickFormatter={(value) => `${value}%`}
                  />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'hsl(var(--card))', 
                      border: '1px solid hsl(var(--border))',
                      borderRadius: '8px',
                    }}
                    formatter={(value: number, name: string) => {
                      if (name === 'winRate') return [`${value.toFixed(1)}%`, 'Win Rate'];
                      if (name === 'trades') return [value, 'Trades'];
                      return [value, name];
                    }}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="winRate" 
                    stroke={CHART_COLORS.primary}
                    strokeWidth={2}
                    dot={{ fill: CHART_COLORS.primary, strokeWidth: 0, r: 4 }}
                    activeDot={{ r: 6, fill: CHART_COLORS.primary }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Instrument Distribution */}
        <Card className="glass border-border/50">
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <PieChart className="h-4 w-4 text-primary" />
              By Instrument
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-48 sm:h-64 flex items-center">
              <ResponsiveContainer width="100%" height="100%">
                <RechartsPieChart>
                  <Pie
                    data={instrumentStats}
                    cx="50%"
                    cy="50%"
                    innerRadius={50}
                    outerRadius={80}
                    paddingAngle={2}
                    dataKey="trades"
                    nameKey="name"
                    label={({ name, percent }) => `${name} (${(percent * 100).toFixed(0)}%)`}
                    labelLine={false}
                  >
                    {instrumentStats.map((_, index) => (
                      <Cell key={`cell-${index}`} fill={PIE_COLORS[index % PIE_COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'hsl(var(--card))', 
                      border: '1px solid hsl(var(--border))',
                      borderRadius: '8px',
                    }}
                    formatter={(value: number, name: string, props) => {
                      const data = props.payload;
                      return [
                        `${value} trades | ${data.winRate.toFixed(0)}% WR | ${formatCurrency(data.pnl)}`,
                        data.name
                      ];
                    }}
                  />
                </RechartsPieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Detailed Stats Table */}
      <Card className="glass border-border/50">
        <CardHeader className="pb-2">
          <CardTitle className="text-base">Detailed Statistics</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
            <div className="space-y-3">
              <div>
                <p className="text-muted-foreground">Largest Win</p>
                <p className="font-mono text-success">{formatCurrency(stats?.largestWin || 0)}</p>
              </div>
              <div>
                <p className="text-muted-foreground">Largest Loss</p>
                <p className="font-mono text-destructive">{formatCurrency(stats?.largestLoss || 0)}</p>
              </div>
            </div>
            <div className="space-y-3">
              <div>
                <p className="text-muted-foreground">Avg R:R Achieved</p>
                <p className="font-mono text-primary">{stats?.avgRR.toFixed(2) || '0'}</p>
              </div>
              <div>
                <p className="text-muted-foreground">Gross P&L</p>
                <p className="font-mono">{formatCurrency(stats?.totalGrossPnL || 0)}</p>
              </div>
            </div>
            <div className="space-y-3">
              <div>
                <p className="text-muted-foreground">Total Charges</p>
                <p className="font-mono text-warning">{formatCurrency(stats?.totalCharges || 0)}</p>
              </div>
              <div>
                <p className="text-muted-foreground">Charge %</p>
                <p className="font-mono text-warning">
                  {stats?.totalGrossPnL ? ((stats.totalCharges / Math.abs(stats.totalGrossPnL)) * 100).toFixed(1) : 0}%
                </p>
              </div>
            </div>
            <div className="space-y-3">
              <div>
                <p className="text-muted-foreground">Win/Loss Ratio</p>
                <p className="font-mono text-primary">
                  {stats?.avgLoss ? (stats.avgWin / stats.avgLoss).toFixed(2) : '∞'}
                </p>
              </div>
              <div>
                <p className="text-muted-foreground">Expectancy</p>
                <p className={`font-mono ${(stats?.expectancy || 0) >= 0 ? 'text-success' : 'text-destructive'}`}>
                  {formatCurrency(stats?.expectancy || 0)}
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default PerformanceDashboard;
