import { HelpCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const HelpGuide = () => {
  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-foreground">
          <HelpCircle className="w-5 h-5" />
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-2xl max-h-[85vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <HelpCircle className="w-5 h-5 text-primary" />
            How to Use — Complete Field Guide
          </DialogTitle>
        </DialogHeader>
        <ScrollArea className="h-[65vh] pr-4">
          <Accordion type="single" collapsible className="w-full">
            {/* EQUITY TAB */}
            <AccordionItem value="equity">
              <AccordionTrigger className="text-primary font-semibold">📈 Equity Calculator</AccordionTrigger>
              <AccordionContent className="space-y-4 text-sm text-muted-foreground">
                <Section title="Capital & Risk Settings">
                  <Field name="Total Capital" desc="Your entire trading capital — the total money in your trading account." example="₹5,00,000" />
                  <Field name="Capital Allocation (% or Fixed)" desc="How much of your total capital you want to deploy on this trade. Toggle between Percentage mode or Fixed Amount mode." example="Percentage: 20% of ₹5L = ₹1,00,000 deployed | Fixed: ₹50,000" />
                  <Field name="Leverage" desc="Margin multiplier from your broker. CNC = 1x (delivery, no leverage). 2x-5x = intraday leverage. Higher leverage = more buying power but more risk." example="CNC (1x) for delivery | 5x for intraday scalping — ₹1L deployed × 5x = ₹5L buying power" />
                  <Field name="Position Sizing Mode" desc="Choose how quantity is calculated. Risk-Based: calculates shares from your risk amount ÷ risk per share. Max Buying Power: uses all available buying power to buy max shares." example="Risk-Based: safer, controlled losses | Max Buying Power: aggressive, uses full margin" />
                  <Field name="Risk Type (% or Fixed)" desc="How you define your risk per trade. Percentage: risk a % of deployed capital. Fixed Amount: risk an exact rupee amount. Only visible in Risk-Based mode." example="1% of ₹1L deployed = ₹1,000 risk | Fixed: ₹2,500" />
                  <Field name="Risk Per Trade (%)" desc="Percentage of deployed capital you're willing to lose if stop loss is hit. Recommended: 0.5% to 2%." example="1% risk on ₹1,00,000 = ₹1,000 max loss" />
                  <Field name="Risk Amount (₹)" desc="Exact rupee amount you're willing to lose on this trade. Shown when Risk Type is Fixed." example="₹1,500 — you'll lose max ₹1,500 if SL is hit" />
                </Section>

                <Section title="Trade Setup">
                  <Field name="Trade Direction (LONG / SHORT)" desc="LONG = you buy first and sell later (bullish, expecting price to rise). SHORT = you sell first and buy later (bearish, expecting price to fall)." example="LONG: Buy at ₹1,250, sell at ₹1,290 | SHORT: Sell at ₹1,250, buy at ₹1,210" />
                  <Field name="Stock Symbol" desc="The NSE/BSE ticker symbol of the stock you're trading." example="RELIANCE, TCS, INFY, HDFCBANK" />
                  <Field name="Entry Price (₹)" desc="The price at which you plan to enter/buy the stock." example="₹1,250.50" />
                  <Field name="Stop Loss (₹)" desc="The price at which you'll exit to limit your loss. For LONG: must be below entry. For SHORT: must be above entry." example="LONG: Entry ₹1,250, SL ₹1,230 (₹20 risk per share) | SHORT: Entry ₹1,250, SL ₹1,270" />
                  <Field name="Target Price (₹)" desc="The price at which you'll book profit. For LONG: must be above entry. For SHORT: must be below entry." example="LONG: Target ₹1,290 (₹40 reward per share) | SHORT: Target ₹1,210" />
                </Section>

                <Section title="Calculated Results (Output Panel)">
                  <Field name="Quantity (auto)" desc="Number of shares to buy. In Risk-Based mode: Risk Amount ÷ Risk Per Share. In Max Buying Power mode: Buying Power ÷ Entry Price. May be capped if position exceeds buying power." example="₹1,000 risk ÷ ₹20 per share = 50 shares" />
                  <Field name="Risk Amount" desc="Actual rupee amount you'll lose if stop loss is hit. Quantity × Risk Per Share." example="50 shares × ₹20 = ₹1,000" />
                  <Field name="Margin Required" desc="Capital blocked by your broker. For CNC (1x): full position value. For leveraged: Position Value ÷ Leverage." example="50 shares × ₹1,250 = ₹62,500 position | At 5x: ₹12,500 margin" />
                  <Field name="Position Value" desc="Total value of your trade. Quantity × Entry Price." example="50 × ₹1,250 = ₹62,500" />
                  <Field name="Potential Profit (Net)" desc="Expected profit if target is hit, AFTER deducting brokerage + STT + GST + stamp duty + SEBI charges." example="Gross: ₹2,000 − Charges: ₹185 = ₹1,815 net profit" />
                  <Field name="Risk:Reward Ratio" desc="Reward per share ÷ Risk per share. Shows how much you stand to gain vs. lose. Aim for ≥ 2:1." example="₹40 reward ÷ ₹20 risk = 2:1 R:R" />
                  <Field name="SL % / Target %" desc="Percentage move from entry to stop loss and target. Helps gauge if your levels are realistic." example="SL: 1.6% below entry | Target: 3.2% above entry" />
                  <Field name="Capital at Risk %" desc="What percentage of your TOTAL capital is at risk in this trade." example="₹1,000 risk on ₹5L capital = 0.2% capital at risk" />
                  <Field name="Total Charges" desc="Auto-calculated brokerage, STT, transaction charges, GST, SEBI fees, stamp duty for Indian markets. Different for CNC vs Intraday." example="Intraday: ~₹150-300 | CNC: ~₹50-150 (depends on position size)" />
                  <Field name="Trailing SL Levels (1R, 2R, 3R)" desc="After entering, move your stop loss to these levels as price moves in your favor. 1R = entry + 1× risk, 2R = entry + 2× risk, etc. This protects profits." example="Entry ₹1,250, Risk ₹20 → 1R: ₹1,270 (move SL to entry) | 2R: ₹1,290 (move SL to 1R) | 3R: ₹1,310 (move SL to 2R)" />
                </Section>

                <Section title="Warnings & Alerts">
                  <Field name="⚠️ Quantity Capped" desc="Appears when your risk-based quantity would require more margin than your deployed capital allows. The app automatically caps quantity to fit your capital." example="Risk says 100 shares but you can only afford 50 — quantity capped to 50" />
                  <Field name="⚠️ Position Exceeds Buying Power" desc="Appears when your position value exceeds available buying power (Deployed Capital × Leverage)." example="₹2L buying power but position is ₹3L — reduce quantity or increase capital" />
                  <Field name="Invalid Setup" desc="Entry, SL, and Target must be logically consistent. For LONG: SL < Entry < Target. For SHORT: Target < Entry < SL." example="LONG with SL above entry = invalid setup" />
                </Section>
              </AccordionContent>
            </AccordionItem>

            {/* OPTIONS TAB */}
            <AccordionItem value="options">
              <AccordionTrigger className="text-primary font-semibold">⚡ Options Calculator</AccordionTrigger>
              <AccordionContent className="space-y-4 text-sm text-muted-foreground">
                <Section title="Option Setup">
                  <Field name="Instrument Type (Stock / Index)" desc="Stock Options: options on individual stocks like RELIANCE, TCS. Index Options: options on NIFTY, BANKNIFTY, FINNIFTY, MIDCPNIFTY." example="Stock Options for RELIANCE | Index Options for NIFTY" />
                  <Field name="Stock Symbol" desc="Ticker of the stock (only for Stock Options). Enter the exact NSE symbol." example="RELIANCE, INFY, TCS, HDFCBANK" />
                  <Field name="Stock Lot Size" desc="Number of shares in one lot for stock options. Check NSE website for exact lot sizes as they change periodically." example="RELIANCE: 250, TCS: 150, INFY: 300" />
                  <Field name="Index" desc="Select the index (only for Index Options). Lot sizes are auto-filled: NIFTY=25, BANKNIFTY=15, FINNIFTY=25, MIDCPNIFTY=50." example="NIFTY (Lot: 25)" />
                  <Field name="Option Type (CE / PE)" desc="CE = Call Option (bullish, profits when price goes UP). PE = Put Option (bearish, profits when price goes DOWN)." example="CE if you think NIFTY will go above 24,500 | PE if you think it will fall below" />
                  <Field name="Spot Price (₹)" desc="Current market price of the underlying index. Only for Index options — used for Greeks calculation." example="₹24,500 (current NIFTY level)" />
                  <Field name="Strike Price (₹)" desc="The strike level of the option contract you're trading. Only for Index options — used for Greeks." example="₹24,500 CE (ATM) or ₹24,600 CE (OTM)" />
                  <Field name="Days to Expiry" desc="Number of calendar days remaining until option expires. Used for Greeks calculation. Weekly expiry = 0-7 days, Monthly = up to 30." example="3 days for weekly | 15 days for monthly" />
                  <Field name="IV (Implied Volatility %)" desc="Market's expected volatility. Higher IV = costlier premiums. Defaults to 15%. Check option chain for actual IV." example="12% (low vol, cheap premiums) | 25% (high vol, expensive premiums)" />
                </Section>

                <Section title="Position Sizing">
                  <Field name="Capital" desc="Total capital available for options trading." example="₹2,00,000" />
                  <Field name="Risk Type (% / Fixed)" desc="Same as Equity — choose percentage or fixed rupee amount for risk." example="2% of ₹2L = ₹4,000 risk | Fixed ₹3,000" />
                  <Field name="Premium (Entry)" desc="Price per unit you pay to buy the option. This is your entry cost per share/unit." example="₹150 premium for NIFTY 24500 CE" />
                  <Field name="Stop Loss Premium" desc="Premium level at which you'll exit to limit loss. Must be BELOW entry premium for bought options." example="₹120 (you lose ₹30 per unit if SL hit)" />
                  <Field name="Target Premium" desc="Premium level at which you'll book profit. Must be ABOVE entry premium for bought options." example="₹210 (you gain ₹60 per unit if target hit)" />
                </Section>

                <Section title="Calculated Results">
                  <Field name="Lots (auto)" desc="Number of lots to trade. Calculated as: Risk Amount ÷ (Premium loss per unit × Lot Size). Capped if position exceeds capital." example="₹4,000 risk ÷ (₹30 × 25) = 5.3 → 5 lots" />
                  <Field name="Quantity" desc="Total units = Lots × Lot Size." example="5 lots × 25 = 125 units" />
                  <Field name="Position Value" desc="Total cost to enter the position = Quantity × Entry Premium." example="125 × ₹150 = ₹18,750" />
                  <Field name="Max Affordable Lots" desc="Maximum lots you can buy with your capital = Capital ÷ (Premium × Lot Size)." example="₹2,00,000 ÷ (₹150 × 25) = 53 lots max" />
                  <Field name="Risk Amount" desc="Actual amount you'll lose if SL hit = Lots × (Entry − SL) × Lot Size + Charges." example="5 × ₹30 × 25 = ₹3,750 + charges" />
                  <Field name="Potential Profit (Net)" desc="Net profit after charges if target hit." example="5 × ₹60 × 25 = ₹7,500 − charges" />
                  <Field name="R:R Ratio" desc="Reward per lot ÷ Risk per lot." example="₹60 reward ÷ ₹30 risk = 2:1" />
                  <Field name="One Lot Summary" desc="Shows cost, risk, and reward for a single lot — useful for quick reference even without full position sizing." example="1 Lot: Cost ₹3,750, Risk ₹750, Reward ₹1,500" />
                </Section>

                <Section title="Greeks (Index Options Only)">
                  <Field name="Delta (Δ)" desc="How much the option price changes for every ₹1 move in the underlying. CE delta: 0 to 1, PE delta: −1 to 0. ATM ≈ 0.5." example="Delta 0.55 → NIFTY moves ₹100, option moves ~₹55" />
                  <Field name="Gamma (Γ)" desc="Rate of change of Delta. Higher near expiry and ATM. Tells you how fast delta will change." example="Gamma 0.003 → Delta changes by 0.003 for every ₹1 move" />
                  <Field name="Theta (Θ)" desc="Time decay — how much premium the option loses each day. Always negative for bought options. Accelerates near expiry." example="Theta −5.2 → Option loses ₹5.20 per day just from time passing" />
                  <Field name="Vega (ν)" desc="Sensitivity to implied volatility changes. Higher vega = more affected by IV changes." example="Vega 8.5 → 1% IV increase adds ₹8.50 to premium" />
                  <Field name="Theoretical Premium" desc="Fair value of the option based on Black-Scholes model using your inputs." example="₹148.50 (compare with actual market premium)" />
                </Section>
              </AccordionContent>
            </AccordionItem>

            {/* FUTURES TAB */}
            <AccordionItem value="futures">
              <AccordionTrigger className="text-primary font-semibold">📊 Futures Calculator</AccordionTrigger>
              <AccordionContent className="space-y-4 text-sm text-muted-foreground">
                <Section title="Capital & Risk Settings">
                  <Field name="Total Capital" desc="Total capital in your trading account for futures." example="₹10,00,000" />
                  <Field name="Capital Allocation (% or Fixed)" desc="How much capital to deploy for this futures trade." example="20% of ₹10L = ₹2,00,000 deployed" />
                  <Field name="Position Sizing Mode" desc="Risk-Based: lots calculated from risk amount. Max Margin: uses all deployed capital as margin to take maximum lots." example="Risk-Based for controlled risk | Max Margin for aggressive sizing" />
                  <Field name="Risk Type (% or Fixed)" desc="Define risk as percentage of deployed capital or exact rupee amount." example="1% of ₹2L = ₹2,000 risk" />
                </Section>

                <Section title="Futures Trade Setup">
                  <Field name="Trade Direction (LONG / SHORT)" desc="LONG: buy futures expecting price rise. SHORT: sell futures expecting price drop." example="LONG NIFTY FUT at ₹24,500" />
                  <Field name="Symbol" desc="Futures contract symbol." example="NIFTY, BANKNIFTY, RELIANCE, TCS" />
                  <Field name="Lot Size" desc="Number of units per lot. NIFTY=25, BANKNIFTY=15. For stocks, check NSE." example="25 for NIFTY FUT" />
                  <Field name="Margin %" desc="Percentage of contract value blocked as margin by your broker. Typically 10-20% for index futures, higher for stocks." example="15% margin → ₹24,500 × 25 × 15% = ₹91,875 per lot" />
                  <Field name="Entry Price (₹)" desc="Price at which you enter the futures position." example="₹24,500" />
                  <Field name="Stop Loss (₹)" desc="Price at which you exit to limit loss." example="₹24,450 (₹50 risk per unit)" />
                  <Field name="Target Price (₹)" desc="Price at which you book profit." example="₹24,600 (₹100 reward per unit)" />
                  <Field name="Expiry Date" desc="Contract expiration date. Current month, next month, or far month." example="27 Feb 2026 (monthly expiry)" />
                </Section>

                <Section title="Calculated Results">
                  <Field name="Lots (auto)" desc="Number of lots. Risk-Based: Risk Amount ÷ (Risk Per Unit × Lot Size). Capped if margin exceeds deployed capital." example="₹2,000 ÷ (₹50 × 25) = 1.6 → 1 lot" />
                  <Field name="Quantity" desc="Total units = Lots × Lot Size." example="1 lot × 25 = 25 units" />
                  <Field name="Contract Value" desc="Total contract value = Quantity × Entry Price." example="25 × ₹24,500 = ₹6,12,500" />
                  <Field name="Margin Required" desc="Capital blocked = Contract Value × Margin %. This is what your broker blocks." example="₹6,12,500 × 15% = ₹91,875" />
                  <Field name="Risk Amount" desc="Actual loss if SL hit = Quantity × Risk per unit + Charges." example="25 × ₹50 = ₹1,250 + charges" />
                  <Field name="Potential Profit (Net)" desc="Net profit after charges if target hit." example="25 × ₹100 = ₹2,500 − charges" />
                  <Field name="R:R Ratio" desc="Reward ÷ Risk per unit." example="₹100 ÷ ₹50 = 2:1" />
                  <Field name="Trailing SL Levels" desc="Same as Equity — 1R, 2R, 3R trailing stop loss levels to lock in profits." example="Entry ₹24,500, Risk ₹50 → 1R: ₹24,550, 2R: ₹24,600, 3R: ₹24,650" />
                  <Field name="Total Charges" desc="Auto-calculated F&O charges — brokerage, STT, exchange charges, GST, stamp duty, SEBI fees." example="~₹100-400 depending on contract value" />
                </Section>
              </AccordionContent>
            </AccordionItem>

            {/* JOURNAL TAB */}
            <AccordionItem value="journal">
              <AccordionTrigger className="text-primary font-semibold">📖 Trading Journal</AccordionTrigger>
              <AccordionContent className="space-y-4 text-sm text-muted-foreground">
                <Section title="Trade Entry Form">
                  <Field name="Trade Date" desc="Date on which you took the trade. Defaults to today." example="2026-02-25" />
                  <Field name="Symbol" desc="Stock or index name you traded." example="RELIANCE, NIFTY, TCS" />
                  <Field name="Trade Type (LONG / SHORT)" desc="Direction of your trade — LONG (buy) or SHORT (sell)." example="LONG" />
                  <Field name="Instrument (Equity / Options / Futures)" desc="Type of instrument you traded. Determines how P&L and charges are calculated." example="EQUITY for cash trades, OPTIONS for F&O" />
                  <Field name="Option Type (CE / PE)" desc="Only for Options — whether it was a Call or Put." example="CE" />
                  <Field name="Strike Price" desc="Only for Options — the strike price of the option contract." example="₹24,500" />
                  <Field name="Expiry Date" desc="Only for Options/Futures — contract expiry date." example="2026-02-27" />
                  <Field name="Entry Price (₹)" desc="Price at which you entered the trade." example="₹150.00" />
                  <Field name="Exit Price (₹)" desc="Price at which you exited. Leave blank for OPEN trades. Set when closing the trade." example="₹185.00 (set when closing)" />
                  <Field name="Quantity" desc="Total number of shares/units traded." example="250 shares or 5 lots × 25 = 125 units" />
                  <Field name="Stop Loss (₹)" desc="Your planned stop loss when entering." example="₹140" />
                  <Field name="Target (₹)" desc="Your planned target when entering." example="₹180" />
                  <Field name="Charges (₹)" desc="Brokerage and other charges. Enter manually or it's auto-calculated." example="₹312" />
                  <Field name="Capital at Entry" desc="Your total capital when you took this trade. Used to calculate position size %." example="₹5,00,000" />
                  <Field name="Strategy" desc="Name of your trading strategy for later analysis and filtering." example="Breakout, Pullback, Mean Reversion, Momentum" />
                  <Field name="Setup Type" desc="Specific pattern or setup that triggered the trade." example="Flag Breakout, Double Bottom, Support Bounce, Gap Fill" />
                  <Field name="Notes" desc="Free-text notes — what you observed, what went right/wrong. Your future self will thank you." example="Entered on high volume breakout above ₹1,250 resistance. Trailed SL after 1:1 achieved." />
                  <Field name="Status (OPEN / CLOSED)" desc="OPEN = trade is live. CLOSED = exited with an exit price. Auto-sets to CLOSED when exit price is provided." example="OPEN → click 'Close Trade' → enter exit price → CLOSED" />
                </Section>

                <Section title="Calculated Fields (Auto)">
                  <Field name="Gross P&L" desc="Profit/loss before charges. For LONG: (Exit − Entry) × Qty. For SHORT: (Entry − Exit) × Qty." example="(₹185 − ₹150) × 125 = ₹4,375" />
                  <Field name="Net P&L" desc="Gross P&L minus charges." example="₹4,375 − ₹312 = ₹4,063" />
                  <Field name="Risk:Reward Ratio" desc="Auto-calculated from entry, SL, and target." example="2:1" />
                  <Field name="Risk Amount" desc="Potential loss based on entry and SL." example="(₹150 − ₹140) × 125 = ₹1,250" />
                  <Field name="Position Size %" desc="What % of your capital this trade represented." example="₹18,750 position ÷ ₹5,00,000 capital = 3.75%" />
                </Section>

                <Section title="Actions">
                  <Field name="Close Trade" desc="Click to enter exit price and close an OPEN trade. Auto-calculates P&L and sends Telegram notification." example="Click 'Close' → Enter ₹185 → Trade marked CLOSED with P&L" />
                  <Field name="Edit Trade" desc="Modify any field of an existing trade." example="Fix entry price or add notes after the fact" />
                  <Field name="Delete Trade" desc="Permanently remove a trade from your journal." example="Delete accidental or test entries" />
                  <Field name="Export CSV" desc="Download all trades as a CSV file for Excel/Google Sheets analysis." example="trading_journal_2026-02-25.csv" />
                  <Field name="Generate Summary" desc="Generate weekly or monthly summary and send to Telegram + Google Sheets." example="Weekly summary: 12 trades, 58% win rate, ₹8,500 net P&L" />
                  <Field name="Sync to Google Sheets" desc="Auto-syncs trades to your configured Google Sheet (set Sheet ID in Settings)." example="Each new/closed trade appended to your Sheet" />
                </Section>
              </AccordionContent>
            </AccordionItem>

            {/* DASHBOARD TAB */}
            <AccordionItem value="dashboard">
              <AccordionTrigger className="text-primary font-semibold">📊 Performance Dashboard</AccordionTrigger>
              <AccordionContent className="space-y-4 text-sm text-muted-foreground">
                <Section title="Key Stats Cards">
                  <Field name="Win Rate" desc="Percentage of closed trades that were profitable. Shows wins vs losses count." example="62% (31W / 19L out of 50 trades)" />
                  <Field name="Total P&L" desc="Sum of all net P&L across closed trades. Also shows total charges paid." example="₹23,450 net P&L | ₹4,200 total charges" />
                  <Field name="Profit Factor" desc="Total profits ÷ Total losses. > 1 means profitable overall. > 1.5 is good. > 2 is excellent. ∞ means no losing trades." example="₹65,100 profits ÷ ₹41,650 losses = 1.56" />
                  <Field name="Avg Win / Avg Loss" desc="Average profit on winning trades vs. average loss on losing trades. Healthy when Avg Win > Avg Loss." example="Avg Win ₹2,100 / Avg Loss ₹1,200 → edge of ₹900 per trade" />
                  <Field name="Expectancy" desc="Expected profit per trade = (Win% × Avg Win) − (Loss% × Avg Loss). Positive = you have an edge." example="(62% × ₹2,100) − (38% × ₹1,200) = ₹846 per trade" />
                </Section>

                <Section title="Charts">
                  <Field name="Cumulative P&L (Area Chart)" desc="Shows your total equity growth over time. Upward trending = consistent profitable trading. Dips show drawdowns." example="Smooth upward curve = strong edge | Choppy = inconsistent" />
                  <Field name="Daily P&L (Bar Chart)" desc="Each bar shows net P&L for a trading day. Green bars = profit days, bars below zero = loss days." example="Spot patterns — do you lose on Mondays? Win more on Thursdays?" />
                  <Field name="Weekly Win Rate Trend (Line Chart)" desc="Your win rate plotted week-by-week over the last 12 weeks. Shows if your consistency is improving or declining." example="Trending up from 45% to 65% = improving | Dropping = need to review" />
                  <Field name="By Instrument (Pie Chart)" desc="Distribution of trades across Equity, Options, and Futures. Shows which instrument you trade most." example="Options: 60%, Equity: 30%, Futures: 10%" />
                </Section>

                <Section title="Detailed Stats Table">
                  <Field name="Largest Win" desc="Your biggest single profitable trade." example="₹12,500 on NIFTY CE" />
                  <Field name="Largest Loss" desc="Your biggest single losing trade. Review this trade to learn from mistakes." example="−₹8,200 on BANKNIFTY PE" />
                  <Field name="Total Charges" desc="All brokerage + taxes paid across all trades. Highlights the cost of trading." example="₹4,200 — consider reducing trade frequency if charges are too high" />
                  <Field name="Gross vs Net P&L" desc="Gross is before charges, Net is after. The difference shows how much charges eat into your profits." example="Gross ₹27,650 − Charges ₹4,200 = Net ₹23,450" />
                  <Field name="Avg R:R" desc="Average risk-reward ratio across all trades with R:R data." example="1.8:1 average" />
                  <Field name="Instrument-wise Stats" desc="P&L, trade count, and win rate broken down by instrument type." example="Equity: 30 trades, 67% win rate, ₹15K P&L | Options: 20 trades, 55% win rate, ₹8K P&L" />
                </Section>
              </AccordionContent>
            </AccordionItem>

            {/* SETTINGS */}
            <AccordionItem value="settings">
              <AccordionTrigger className="text-primary font-semibold">⚙️ Settings</AccordionTrigger>
              <AccordionContent className="space-y-4 text-sm text-muted-foreground">
                <Section title="Google Sheets Integration">
                  <Field name="Google Sheet ID" desc="The unique ID from your Google Sheet URL. Found between /d/ and /edit in the URL. Used to auto-sync trades and calculator data." example="URL: docs.google.com/spreadsheets/d/1aBcDeFgHiJkLmN/edit → ID: 1aBcDeFgHiJkLmN" />
                </Section>
                <Section title="Telegram Notifications">
                  <Field name="Enable Telegram Alerts" desc="Toggle to send real-time notifications to Telegram when trades are added/closed." example="ON: Get instant alerts | OFF: No Telegram messages" />
                  <Field name="Send Summary Now" desc="Manually trigger a daily, weekly, or monthly summary to Telegram. Auto-sends daily at 3:35 PM IST, weekly on Fridays, monthly on 1st." example="Click 'Daily' to send today's summary immediately" />
                </Section>
                <Section title="Auto-save">
                  <Field name="Auto-save Calculations" desc="When enabled, valid calculator outputs are automatically saved without clicking Save." example="ON: calculations auto-saved | OFF: manual save required" />
                </Section>
              </AccordionContent>
            </AccordionItem>

            {/* GENERAL TIPS */}
            <AccordionItem value="tips">
              <AccordionTrigger className="text-primary font-semibold">💡 Pro Tips & Best Practices</AccordionTrigger>
              <AccordionContent className="space-y-3 text-sm text-muted-foreground">
                <p>• <strong>Never risk more than 1-2%</strong> of your capital on a single trade — this is the #1 rule of survival.</p>
                <p>• <strong>Always set a stop loss</strong> before entering — no stop loss = unlimited risk.</p>
                <p>• <strong>Aim for R:R ≥ 2:1</strong> — even a 40% win rate is profitable with 2:1 risk-reward.</p>
                <p>• <strong>Use trailing SL</strong> — move your stop loss to breakeven after 1R, then to 1R after 2R. Lock in profits.</p>
                <p>• <strong>Log every trade</strong> in the Journal — winners AND losers. Reviewing past trades is how you improve.</p>
                <p>• <strong>Check the Dashboard weekly</strong> — are you improving? Which strategy works best? Which instrument gives best results?</p>
                <p>• <strong>Charges matter</strong> — if you're scalping small moves, charges can eat 30-50% of profits. Check your net vs gross P&L.</p>
                <p>• <strong>Position sizing &gt; stock picking</strong> — a great setup with bad sizing will still blow your account.</p>
                <p>• <strong>Avoid revenge trading</strong> — if you hit 3 losses in a row, stop for the day. Come back tomorrow.</p>
                <p>• <strong>Leverage is a double-edged sword</strong> — 5x leverage means 5x losses too. Use CNC for learning, 2-3x for intraday.</p>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
};

const Section = ({ title, children }: { title: string; children: React.ReactNode }) => (
  <div className="space-y-2">
    <h4 className="font-semibold text-foreground text-xs uppercase tracking-wider border-b border-border pb-1">{title}</h4>
    <div className="space-y-2 pl-1">{children}</div>
  </div>
);

const Field = ({ name, desc, example }: { name: string; desc: string; example: string }) => (
  <div className="border-l-2 border-primary/30 pl-3 py-1">
    <p className="font-medium text-foreground">{name}</p>
    <p className="leading-relaxed">{desc}</p>
    <p className="text-xs text-primary/70 mt-0.5">📌 Example: {example}</p>
  </div>
);

export default HelpGuide;
