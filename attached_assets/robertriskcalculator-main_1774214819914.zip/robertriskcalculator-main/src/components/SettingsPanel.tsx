import { useState, useEffect } from "react";
import { Settings, Save, X, FileSpreadsheet, Bell, Send, Loader2, CheckCircle2, TestTube2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Drawer,
  DrawerContent,
  DrawerDescription,
  DrawerHeader,
  DrawerTitle,
  DrawerTrigger,
} from "@/components/ui/drawer";
import { useIsMobile } from "@/hooks/use-mobile";
import { useToast } from "@/hooks/use-toast";

export interface AppSettings {
  spreadsheetId: string;
  telegramEnabled: boolean;
  autoSaveEnabled: boolean;
}

const DEFAULT_SETTINGS: AppSettings = {
  spreadsheetId: "",
  telegramEnabled: true,
  autoSaveEnabled: false,
};

export const getSettings = (): AppSettings => {
  const stored = localStorage.getItem("appSettings");
  if (stored) {
    try {
      return { ...DEFAULT_SETTINGS, ...JSON.parse(stored) };
    } catch {
      return DEFAULT_SETTINGS;
    }
  }
  return DEFAULT_SETTINGS;
};

export const saveSettings = (settings: AppSettings): void => {
  localStorage.setItem("appSettings", JSON.stringify(settings));
  // Dispatch custom event so components can react to settings changes
  window.dispatchEvent(new CustomEvent("settingsChanged", { detail: settings }));
};

const SettingsPanel = () => {
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [settings, setSettings] = useState<AppSettings>(getSettings);
  const [isSendingSummary, setIsSendingSummary] = useState<string | null>(null);
  const [isTesting, setIsTesting] = useState<string | null>(null);

  const testTelegram = async () => {
    setIsTesting('telegram');
    try {
      const { data, error } = await supabase.functions.invoke('telegram-notify', {
        body: {
          action: 'NEW',
          symbol: 'TEST_SIGNAL',
          tradeType: 'BUY',
          instrument: 'Equity',
          entryPrice: 100,
          quantity: 10,
          status: '🧪 Test notification from Settings',
        }
      });
      if (error) throw error;
      toast({ title: "✅ Telegram Test Sent!", description: "Check your Telegram for the test message." });
    } catch (err) {
      console.error('Telegram test error:', err);
      toast({ title: "❌ Telegram Test Failed", description: String(err), variant: "destructive" });
    } finally {
      setIsTesting(null);
    }
  };

  const testGoogleSheets = async () => {
    if (!settings.spreadsheetId) {
      toast({ title: "No Sheet ID", description: "Enter a Google Sheet ID first.", variant: "destructive" });
      return;
    }
    setIsTesting('sheets');
    try {
      const { data, error } = await supabase.functions.invoke('sync-google-sheets', {
        body: {
          spreadsheetId: settings.spreadsheetId,
          trade: {
            id: 'test-' + Date.now(),
            trade_date: new Date().toISOString().split('T')[0],
            symbol: 'TEST_SYNC',
            trade_type: 'BUY',
            instrument: 'Equity',
            entry_price: 100,
            exit_price: 105,
            quantity: 10,
            option_type: null,
            strike_price: null,
            gross_pnl: 50,
            charges: 5,
            net_pnl: 45,
            stop_loss: 95,
            target: 110,
            risk_reward_ratio: 2,
            strategy: 'Test',
            notes: '🧪 Test row from Settings',
            status: 'closed',
          }
        }
      });
      if (error) throw error;
      toast({ title: "✅ Google Sheets Test Sent!", description: "Check your spreadsheet for the test row." });
    } catch (err) {
      console.error('Sheets test error:', err);
      toast({ title: "❌ Google Sheets Test Failed", description: String(err), variant: "destructive" });
    } finally {
      setIsTesting(null);
    }
  };

  const sendSummary = async (period: 'daily' | 'weekly' | 'monthly') => {
    setIsSendingSummary(period);
    try {
      const { error } = await supabase.functions.invoke('auto-summary', {
        body: { period }
      });
      if (error) throw error;
      toast({ title: "Sent!", description: `${period} summary sent to Telegram.` });
    } catch (err) {
      console.error('Summary send error:', err);
      toast({ title: "Error", description: `Failed to send ${period} summary`, variant: "destructive" });
    } finally {
      setIsSendingSummary(null);
    }
  };

  useEffect(() => {
    // Load settings on mount
    setSettings(getSettings());
  }, [open]);

  const handleSave = () => {
    saveSettings(settings);
    toast({
      title: "Settings Saved",
      description: "Your preferences have been updated.",
    });
    setOpen(false);
  };

  const handleChange = <K extends keyof AppSettings>(key: K, value: AppSettings[K]) => {
    setSettings(prev => ({ ...prev, [key]: value }));
  };
  const isMobile = useIsMobile();

  const cleanup = () => {
    document.body.style.pointerEvents = '';
    document.body.style.overflow = '';
    document.body.style.paddingRight = '';
    document.body.removeAttribute('data-scroll-locked');
  };

  const handleOpenChange = (isOpen: boolean) => {
    setOpen(isOpen);
    if (!isOpen) {
      cleanup();
      setTimeout(cleanup, 50);
      setTimeout(cleanup, 200);
    }
  };

  const settingsHeader = (
    <>
      <div className="flex items-center gap-2">
        <Settings className="w-5 h-5 text-primary" />
        App Settings
      </div>
      <p className="text-sm text-muted-foreground">
        Configure your Google Sheets and notification preferences. These settings apply to all calculators.
      </p>
    </>
  );

  const settingsContent = (
    <>
      <div className="space-y-6 py-4">
        {/* Google Sheets Settings */}
        <div className="space-y-4">
          <div className="flex items-center gap-2 text-sm font-medium">
            <FileSpreadsheet className="w-4 h-4 text-primary" />
            Google Sheets Integration
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="spreadsheetId" className="text-muted-foreground">
              Google Sheet ID
            </Label>
            <Input
              id="spreadsheetId"
              type="text"
              value={settings.spreadsheetId}
              onChange={(e) => handleChange("spreadsheetId", e.target.value)}
              placeholder="Enter your Google Sheet ID"
              className="font-mono text-sm"
            />
            <p className="text-xs text-muted-foreground">
              Find this in your Google Sheet URL: docs.google.com/spreadsheets/d/<span className="text-primary font-medium">SHEET_ID</span>/edit
            </p>
            <Button
              variant="outline"
              size="sm"
              className="w-full mt-2 text-xs"
              onClick={testGoogleSheets}
              disabled={isTesting !== null}
            >
              {isTesting === 'sheets' ? <Loader2 className="w-3 h-3 animate-spin mr-1" /> : <TestTube2 className="w-3 h-3 mr-1" />}
              Test Google Sheets Sync
            </Button>
          </div>
        </div>

        {/* Telegram Settings */}
        <div className="space-y-4">
          <div className="flex items-center gap-2 text-sm font-medium">
            <Bell className="w-4 h-4 text-primary" />
            Telegram Notifications
          </div>
          
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="telegramEnabled">Enable Telegram Alerts</Label>
              <p className="text-xs text-muted-foreground">
                Send trade alerts to your Telegram
              </p>
            </div>
            <Switch
              id="telegramEnabled"
              checked={settings.telegramEnabled}
              onCheckedChange={(checked) => handleChange("telegramEnabled", checked)}
            />
          </div>

          <div className="flex items-center gap-2 p-3 rounded-lg bg-primary/5 border border-primary/20">
            <CheckCircle2 className="w-4 h-4 text-primary shrink-0" />
            <p className="text-xs text-muted-foreground">
              Telegram Bot Token & Chat ID are securely configured on the server.
            </p>
          </div>

          <Button
            variant="outline"
            size="sm"
            className="w-full text-xs"
            onClick={testTelegram}
            disabled={isTesting !== null}
          >
            {isTesting === 'telegram' ? <Loader2 className="w-3 h-3 animate-spin mr-1" /> : <TestTube2 className="w-3 h-3 mr-1" />}
            Test Telegram Notification
          </Button>

          {/* Manual Summary Triggers */}
          <div className="space-y-2 pt-2">
            <Label className="text-muted-foreground text-xs">Send Summary Now</Label>
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                className="flex-1 text-xs"
                onClick={() => sendSummary('daily')}
                disabled={isSendingSummary !== null}
              >
                {isSendingSummary === 'daily' ? <Loader2 className="w-3 h-3 animate-spin mr-1" /> : <Send className="w-3 h-3 mr-1" />}
                Daily
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="flex-1 text-xs"
                onClick={() => sendSummary('weekly')}
                disabled={isSendingSummary !== null}
              >
                {isSendingSummary === 'weekly' ? <Loader2 className="w-3 h-3 animate-spin mr-1" /> : <Send className="w-3 h-3 mr-1" />}
                Weekly
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="flex-1 text-xs"
                onClick={() => sendSummary('monthly')}
                disabled={isSendingSummary !== null}
              >
                {isSendingSummary === 'monthly' ? <Loader2 className="w-3 h-3 animate-spin mr-1" /> : <Send className="w-3 h-3 mr-1" />}
                Monthly
              </Button>
            </div>
            <p className="text-xs text-muted-foreground">
              Auto-sends daily at 3:35 PM IST, weekly on Fridays, monthly on 1st
            </p>
          </div>
        </div>

        {/* Auto-save Settings */}
        <div className="space-y-4 pt-2 border-t border-border">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="autoSave">Auto-save Calculations</Label>
              <p className="text-xs text-muted-foreground">
                Automatically save valid calculations
              </p>
            </div>
            <Switch
              id="autoSave"
              checked={settings.autoSaveEnabled}
              onCheckedChange={(checked) => handleChange("autoSaveEnabled", checked)}
            />
          </div>
        </div>
      </div>

      <div className="flex justify-end gap-2 pb-4">
        <Button variant="outline" onClick={() => setOpen(false)}>
          <X className="w-4 h-4 mr-2" />
          Cancel
        </Button>
        <Button onClick={handleSave}>
          <Save className="w-4 h-4 mr-2" />
          Save Settings
        </Button>
      </div>
    </>
  );

  const triggerButton = (
    <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-foreground">
      <Settings className="w-5 h-5" />
    </Button>
  );

  if (isMobile) {
    return (
      <Drawer open={open} onOpenChange={handleOpenChange}>
        <DrawerTrigger asChild>
          {triggerButton}
        </DrawerTrigger>
        <DrawerContent className="max-h-[85vh]">
          <DrawerHeader className="text-left">
            <DrawerTitle className="flex items-center gap-2">
              <Settings className="w-5 h-5 text-primary" />
              App Settings
            </DrawerTitle>
            <DrawerDescription>
              Configure your Google Sheets and notification preferences.
            </DrawerDescription>
          </DrawerHeader>
          <div className="overflow-y-auto px-4">
            {settingsContent}
          </div>
        </DrawerContent>
      </Drawer>
    );
  }

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogTrigger asChild>
        {triggerButton}
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Settings className="w-5 h-5 text-primary" />
            App Settings
          </DialogTitle>
          <DialogDescription>
            Configure your Google Sheets and notification preferences. These settings apply to all calculators.
          </DialogDescription>
        </DialogHeader>
        {settingsContent}
      </DialogContent>
    </Dialog>
  );
};

export default SettingsPanel;
