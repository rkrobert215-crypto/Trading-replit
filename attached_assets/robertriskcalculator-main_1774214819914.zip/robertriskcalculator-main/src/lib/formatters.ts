/**
 * Shared formatting utilities for Indian currency and numbers.
 */

export const formatCurrency = (value: number): string => {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(value);
};

export const formatNumber = (value: number, decimals = 2): string => {
  return new Intl.NumberFormat('en-IN', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  }).format(value);
};

/**
 * Prevent scroll wheel from changing number input values.
 */
export const handleWheel = (e: React.WheelEvent<HTMLInputElement>): void => {
  e.currentTarget.blur();
};
