import { useNavigate } from "react-router-dom";
import { TrendingUp, Activity, Layers, BookOpen, PieChart, BarChart3 } from "lucide-react";
import ThemeSelector from "@/components/ThemeSelector";
import HelpGuide from "@/components/HelpGuide";
import SettingsPanel from "@/components/SettingsPanel";

const cards = [
  {
    title: "Equity Calculator",
    description: "Position sizing & risk management for cash equity trades",
    icon: TrendingUp,
    path: "/equity",
    gradient: "from-emerald-500/20 to-emerald-600/5",
    iconColor: "text-emerald-500",
    border: "hover:border-emerald-500/40",
  },
  {
    title: "Options Calculator",
    description: "Premium-based risk analysis with Greeks & lot sizing",
    icon: Activity,
    path: "/options",
    gradient: "from-blue-500/20 to-blue-600/5",
    iconColor: "text-blue-500",
    border: "hover:border-blue-500/40",
  },
  {
    title: "Futures Calculator",
    description: "Margin-based position sizing for F&O contracts",
    icon: Layers,
    path: "/futures",
    gradient: "from-orange-500/20 to-orange-600/5",
    iconColor: "text-orange-500",
    border: "hover:border-orange-500/40",
  },
  {
    title: "Trading Journal",
    description: "Log, review & analyse every trade you take",
    icon: BookOpen,
    path: "/journal",
    gradient: "from-purple-500/20 to-purple-600/5",
    iconColor: "text-purple-500",
    border: "hover:border-purple-500/40",
  },
  {
    title: "Performance Dashboard",
    description: "Visual analytics & P&L breakdown of your trades",
    icon: PieChart,
    path: "/dashboard",
    gradient: "from-rose-500/20 to-rose-600/5",
    iconColor: "text-rose-500",
    border: "hover:border-rose-500/40",
  },
];

const Home = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-background p-4 md:p-8">
      <div className="max-w-5xl mx-auto space-y-10 animate-fade-in">
        {/* Top bar */}
        <div className="flex justify-end items-center gap-0.5">
          <HelpGuide />
          <ThemeSelector />
          <SettingsPanel />
        </div>

        {/* Hero */}
        <div className="text-center space-y-4">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="p-3 rounded-xl bg-primary/10 glow-primary">
              <BarChart3 className="w-10 h-10 text-primary" />
            </div>
          </div>
          <h1 className="text-4xl md:text-5xl font-extrabold text-foreground tracking-tight">
            Intraday Risk Calculator
          </h1>
          <p className="text-muted-foreground text-lg max-w-xl mx-auto">
            Your all-in-one toolkit for position sizing, risk management &amp; trade journaling in Indian markets.
          </p>
        </div>

        {/* Cards grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {cards.map((card) => (
            <button
              key={card.path}
              onClick={() => navigate(card.path)}
              className={`group relative text-left rounded-2xl border border-border bg-card p-6 transition-all duration-300 hover:shadow-xl hover:-translate-y-1 ${card.border} cursor-pointer`}
            >
              <div className={`absolute inset-0 rounded-2xl bg-gradient-to-br ${card.gradient} opacity-0 group-hover:opacity-100 transition-opacity duration-300`} />
              <div className="relative z-10 space-y-3">
                <div className={`p-2.5 w-fit rounded-lg bg-secondary/60 ${card.iconColor}`}>
                  <card.icon className="w-6 h-6" />
                </div>
                <h2 className="text-xl font-bold text-foreground">{card.title}</h2>
                <p className="text-sm text-muted-foreground leading-relaxed">{card.description}</p>
              </div>
            </button>
          ))}
        </div>

        {/* Footer */}
        <p className="text-center text-muted-foreground text-sm pt-4">
          Risk only what you can afford to lose. Past performance does not guarantee future results.
        </p>
      </div>
    </div>
  );
};

export default Home;
