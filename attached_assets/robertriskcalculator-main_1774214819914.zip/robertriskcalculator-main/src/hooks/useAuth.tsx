import { useState, useEffect, createContext, useContext, ReactNode } from "react";
import { User, Session } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";

interface AuthContextType {
  user: User | null;
  session: Session | null;
  loading: boolean;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let isMounted = true;

    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (_event, nextSession) => {
        if (!isMounted) return;
        setSession(nextSession);
        setUser(nextSession?.user ?? null);
        setLoading(false);
      }
    );

    const withTimeout = async <T,>(promise: Promise<T>, ms: number) => {
      return await Promise.race([
        promise,
        new Promise<T>((_resolve, reject) => {
          setTimeout(() => reject(new Error(`Auth init timeout after ${ms}ms`)), ms);
        }),
      ]);
    };

    const initializeAuth = async () => {
      try {
        type GetSessionResult = Awaited<ReturnType<typeof supabase.auth.getSession>>;
        const res = (await withTimeout(supabase.auth.getSession(), 2500)) as GetSessionResult;
        const { data, error } = res;
        if (error) throw error;

        if (!isMounted) return;
        setSession(data.session);
        setUser(data.session?.user ?? null);
      } catch (error) {
        console.error("Auth session initialization failed:", error);

        // If the stored session/refresh token is corrupted or network is blocked,
        // clear local auth state so the UI can still render in guest mode.
        try {
          await supabase.auth.signOut({ scope: "local" });
        } catch {
          // ignore local signout cleanup errors
        }

        if (!isMounted) return;
        setSession(null);
        setUser(null);
      } finally {
        if (isMounted) setLoading(false);
      }
    };

    void initializeAuth();

    return () => {
      isMounted = false;
      subscription.unsubscribe();
    };
  }, []);

  const signOut = async () => {
    await supabase.auth.signOut();
  };

  return (
    <AuthContext.Provider value={{ user, session, loading, signOut }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
};
